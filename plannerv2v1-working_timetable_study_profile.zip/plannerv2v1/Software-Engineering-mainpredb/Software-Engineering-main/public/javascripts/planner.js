// planner.js
// Handles the weekly timetable grid with week navigation.
// Entries are stored in the database via the server API.

var weekOffset   = 0;  // 0 = current week, -1 = last week, +1 = next week
var editEntryId  = null;
var dayNames     = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

document.addEventListener('DOMContentLoaded', function() {
  updateWeekDisplay();
  loadEntries();
});

// ── Week helpers ──────────────────────────────────────────────────────────────

function getMondayDate(offset) {
  var d   = new Date();
  var day = d.getDay();                        // 0=Sun, 1=Mon ... 6=Sat
  var diff = (day === 0) ? -6 : 1 - day;      // days back to Monday
  d.setDate(d.getDate() + diff + (offset * 7));
  d.setHours(0, 0, 0, 0);
  return d;
}

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}

function formatDate(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

function formatDateShort(d) {
  return pad(d.getDate()) + '/' + pad(d.getMonth() + 1);
}

function updateWeekDisplay() {
  var monday = getMondayDate(weekOffset);
  var sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  // Update week label
  document.getElementById('week-label').textContent =
    formatDateShort(monday) + ' — ' + formatDateShort(sunday) + ' ' + sunday.getFullYear();

  // Update column headers with actual dates
  var headers = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  var dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  for (var i = 0; i < 7; i++) {
    var headerEl = document.getElementById('header-' + headers[i]);
    if (headerEl) {
      var d = new Date(monday);
      d.setDate(monday.getDate() + i);
      headerEl.textContent = dayLabels[i] + ' ' + formatDateShort(d);
    }
  }
}

function getWeekOffsetForDate(dateStr) {
  var parts = dateStr.split('-');
  var target = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  var dow    = target.getDay();
  var diff   = (dow === 0) ? -6 : 1 - dow;
  target.setDate(target.getDate() + diff);
  target.setHours(0, 0, 0, 0);
  var currentMonday = getMondayDate(0);
  return Math.round((target - currentMonday) / (7 * 24 * 60 * 60 * 1000));
}

// ── Load entries for current week ─────────────────────────────────────────────

function loadEntries() {
  var monday     = getMondayDate(weekOffset);
  var weekStart  = formatDate(monday);

  // Clear all cells first
  var cells = document.querySelectorAll('.planner-cell');
  for (var i = 0; i < cells.length; i++) {
    cells[i].innerHTML = '';
  }

  fetch('/api/timetable?weekStart=' + weekStart)
    .then(function(res) { return res.json(); })
    .then(function(entries) {
      console.log('Loaded timetable entries:', entries);

      entries.forEach(function(entry) {
        placeEntry(entry, monday);
      });
    })
    .catch(function(err) { console.error('Load timetable error:', err); });
}

function placeEntry(entry, monday) {
  var dateString = entry.entry_date;
  var parts = dateString.split('-');

  var entryDate = new Date(
    parseInt(parts[0], 10),
    parseInt(parts[1], 10) - 1,
   parseInt(parts[2], 10)
  );

  var entryDay = entryDate.getDay(); 
  // JS: Sunday = 0, Monday = 1, Tuesday = 2, etc.

  var dayIndex = entryDay - 1;
  if (entryDay === 0) {
    dayIndex = 6;
  }

  if (dayIndex < 0 || dayIndex > 6) return;

  var startHour = parseInt(entry.start_time.split(':')[0], 10);
  var startMin = parseInt(entry.start_time.split(':')[1], 10);
  var endHour = parseInt(entry.end_time.split(':')[0], 10);
  var endMin = parseInt(entry.end_time.split(':')[1], 10);

  var startDecimal = startHour + startMin / 60;
  var endDecimal = endHour + endMin / 60;

  var rowIndex = Math.floor(startDecimal) - 8;
  if (rowIndex < 0 || rowIndex >= 11) return;

  var cell = document.querySelector(
    '.planner-cell[data-day="' + dayIndex + '"][data-hour="' + Math.floor(startDecimal) + '"]'
  );

  if (!cell) return;

  var block = document.createElement('div');
  block.className = 'entry-block';

  var duration = endDecimal - startDecimal;
  block.style.height = (duration * 52) + 'px';

  block.innerHTML =
    '<span class="entry-time">' + entry.start_time.substring(0, 5) + '–' + entry.end_time.substring(0, 5) + '</span>' +
    '<span class="entry-desc">' + escapeHtml(entry.description) + '</span>';

  (function(e) {
    block.addEventListener('click', function(ev) {
      ev.stopPropagation();
      openEditModal(e);
    });
  })(entry);

  cell.appendChild(block);
}

// ── Week navigation ───────────────────────────────────────────────────────────

function prevWeek() {
  weekOffset--;
  updateWeekDisplay();
  loadEntries();
}

function nextWeek() {
  weekOffset++;
  updateWeekDisplay();
  loadEntries();
}

// ── Add entry modal ───────────────────────────────────────────────────────────

function openAddModal() {
  // Default date to Monday of current week
  var monday = getMondayDate(weekOffset);
  document.getElementById('add-date').value  = formatDate(monday);
  document.getElementById('add-start').value = '09:00';
  document.getElementById('add-end').value   = '10:00';
  document.getElementById('add-desc').value  = '';
  document.getElementById('add-modal').style.display = 'flex';
}

function closeAddModal() {
  document.getElementById('add-modal').style.display = 'none';
}

function saveNewEntry() {
  var entryDate = document.getElementById('add-date').value;
  var startTime = document.getElementById('add-start').value;
  var endTime   = document.getElementById('add-end').value;
  var desc      = document.getElementById('add-desc').value.trim();

  if (!entryDate || !startTime || !endTime) {
    alert('Please fill in the date and times.');
    return;
  }
  if (endTime <= startTime) {
    alert('End time must be after start time.');
    return;
  }

  fetch('/api/timetable', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ entryDate: entryDate, startTime: startTime, endTime: endTime, description: desc })
  })
    .then(function(res) {
      if (!res.ok) { throw new Error('Server error ' + res.status); }
      return res.json();
    })
    .then(function() {
      closeAddModal();
      loadEntries();
    })
    .catch(function(err) {
      console.error('Save entry error:', err);
      alert('Could not save entry: ' + err.message);
    });
}

// ── Edit entry modal ──────────────────────────────────────────────────────────

function openEditModal(entry) {
  editEntryId = entry.id;
  document.getElementById('edit-date').value  = entry.entry_date.substring(0, 10);
  document.getElementById('edit-start').value = entry.start_time.substring(0, 5);
  document.getElementById('edit-end').value   = entry.end_time.substring(0, 5);
  document.getElementById('edit-desc').value  = entry.description;
  document.getElementById('edit-modal').style.display = 'flex';
}

function closeEditModal() {
  editEntryId = null;
  document.getElementById('edit-modal').style.display = 'none';
}

function saveEditEntry() {
  if (!editEntryId) return;

  var entryDate = document.getElementById('edit-date').value;
  var startTime = document.getElementById('edit-start').value;
  var endTime   = document.getElementById('edit-end').value;
  var desc      = document.getElementById('edit-desc').value.trim();

  if (!entryDate || !startTime || !endTime) {
    alert('Please fill in the date and times.');
    return;
  }
  if (endTime <= startTime) {
    alert('End time must be after start time.');
    return;
  }

  fetch('/api/timetable/' + editEntryId, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ entryDate: entryDate, startTime: startTime, endTime: endTime, description: desc })
  })
    .then(function() {
      closeEditModal();
      loadEntries();
    })
    .catch(function(err) { console.error('Update entry error:', err); });
}

function deleteEntry() {
  if (!editEntryId) return;
  fetch('/api/timetable/' + editEntryId, { method: 'DELETE' })
    .then(function() {
      closeEditModal();
      loadEntries();
    })
    .catch(function(err) { console.error('Delete entry error:', err); });
}

function clearAllEntries() {
  if (!confirm('Clear all timetable entries? This cannot be undone.')) return;
  fetch('/api/timetable/all', { method: 'DELETE' })
    .then(function(r) {
      if (!r.ok) throw new Error('Server error ' + r.status);
      return r.json();
    })
    .then(function() {
      loadEntries();
    })
    .catch(function(err) {
      console.error('Clear all error:', err);
      alert('Could not clear entries: ' + err.message);
    });
}

// ── Semester profile modals ───────────────────────────────────────────────────

function openCreateModal() {
  document.getElementById('create-modal').style.display = 'flex';
}

function closeCreateModal() {
  document.getElementById('create-modal').style.display = 'none';
}

// ── Semester jump modal ───────────────────────────────────────────────────────

function openSemesterModal() {
  document.getElementById('semester-modal').style.display = 'flex';
}

function closeSemesterModal() {
  document.getElementById('semester-modal').style.display = 'none';
}

function jumpToSemester(semNumber) {
  var now   = new Date();
  var year  = now.getFullYear();
  var month = now.getMonth(); // 0-indexed
  var targetMonth;

  if (semNumber === 1) {
    targetMonth = 8; // September
    // If today is already past September, keep current year (jump back to its start)
  } else if (semNumber === 2) {
    targetMonth = 0; // January
    if (month > 2) year++; // past March → next year's January
  } else {
    targetMonth = 3; // April
    if (month > 5) year++; // past June → next year's April
  }

  // First day of the target month, then snap back to Monday
  var target   = new Date(year, targetMonth, 1);
  var dow      = target.getDay();
  var toMon    = (dow === 0) ? -6 : 1 - dow;
  target.setDate(target.getDate() + toMon);

  var currentMonday = getMondayDate(0);
  var msPerWeek     = 7 * 24 * 60 * 60 * 1000;
  weekOffset = Math.round((target - currentMonday) / msPerWeek);

  closeSemesterModal();
  updateWeekDisplay();
  loadEntries();
}

// ── Coursework modals ─────────────────────────────────────────────────────────

var editCwId = null;

function openAddCwModal(moduleCode) {
  document.getElementById('cw-module-code').value = moduleCode;
  document.getElementById('cw-name').value         = '';
  document.getElementById('cw-type').value         = 'coursework';
  document.getElementById('cw-weighting').value    = '';
  document.getElementById('cw-due').value          = '';
  document.getElementById('add-cw-modal').style.display = 'flex';
}

function closeAddCwModal() {
  document.getElementById('add-cw-modal').style.display = 'none';
}

function saveNewCw() {
  var moduleCode = document.getElementById('cw-module-code').value;
  var name       = document.getElementById('cw-name').value.trim();
  var type       = document.getElementById('cw-type').value;
  var weighting  = document.getElementById('cw-weighting').value;
  var dueDate    = document.getElementById('cw-due').value;

  if (!name || !dueDate) {
    alert('Please fill in the name and due date.');
    return;
  }

  fetch('/api/courseworks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ moduleCode: moduleCode, name: name, type: type, weighting: weighting || null, dueDate: dueDate })
  })
    .then(function(r) {
      if (!r.ok) throw new Error('Server error ' + r.status);
      return r.json();
    })
    .then(function() {
      closeAddCwModal();
      location.reload();
    })
    .catch(function(err) { alert('Could not save: ' + err.message); });
}

function openEditCwModal(btn) {
  editCwId = parseInt(btn.dataset.id);
  document.getElementById('edit-cw-name').value      = btn.dataset.name;
  document.getElementById('edit-cw-type').value      = btn.dataset.type || 'coursework';
  document.getElementById('edit-cw-weighting').value = btn.dataset.weighting || '';
  document.getElementById('edit-cw-due').value       = btn.dataset.due || '';
  // Reset file input and picker
  document.getElementById('edit-cw-file').value      = '';
  document.getElementById('edit-cw-pdf-items').style.display = 'none';
  document.getElementById('edit-cw-pdf-list').innerHTML = '';
  document.getElementById('edit-cw-modal').style.display = 'flex';
}

document.addEventListener('DOMContentLoaded', function() {
  var fileInput = document.getElementById('edit-cw-file');
  if (fileInput) {
    fileInput.addEventListener('change', function() {
      var file = fileInput.files[0];
      if (!file) return;
      var fd = new FormData();
      fd.append('cwFile', file);
      fetch('/api/courseworks/parse-pdf', { method: 'POST', body: fd })
        .then(function(r) { return r.json(); })
        .then(function(data) {
          if (data.error) { alert('Could not parse PDF: ' + data.error); return; }
          if (!data.items || data.items.length === 0) {
            alert('No coursework deadlines found in this PDF.');
            return;
          }
          if (data.items.length === 1) {
            fillEditCwForm(data.items[0]);
          } else {
            showCwPickList(data.items);
          }
        })
        .catch(function(err) { alert('Upload error: ' + err.message); });
    });
  }
});

function fillEditCwForm(item) {
  document.getElementById('edit-cw-name').value      = item.name      || '';
  document.getElementById('edit-cw-weighting').value = item.weighting || '';
  document.getElementById('edit-cw-due').value       = item.dueDate   || '';
  document.getElementById('edit-cw-pdf-items').style.display = 'none';
}

function showCwPickList(items) {
  var list    = document.getElementById('edit-cw-pdf-list');
  var wrapper = document.getElementById('edit-cw-pdf-items');
  list.innerHTML = '';
  items.forEach(function(item) {
    var btn = document.createElement('button');
    btn.type      = 'button';
    btn.className = 'cw-pick-btn';
    btn.textContent = item.name + (item.weighting ? ' (' + item.weighting + '%)' : '') + ' — ' + (item.dueDate || '');
    btn.addEventListener('click', function() { fillEditCwForm(item); });
    list.appendChild(btn);
  });
  wrapper.style.display = 'block';
}

function closeEditCwModal() {
  editCwId = null;
  document.getElementById('edit-cw-modal').style.display = 'none';
}

function saveEditCw() {
  if (!editCwId) return;
  var name      = document.getElementById('edit-cw-name').value.trim();
  var type      = document.getElementById('edit-cw-type').value;
  var weighting = document.getElementById('edit-cw-weighting').value;
  var dueDate   = document.getElementById('edit-cw-due').value;

  if (!name || !dueDate) {
    alert('Please fill in the name and due date.');
    return;
  }

  fetch('/api/courseworks/' + editCwId, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: name, type: type, weighting: weighting || null, dueDate: dueDate })
  })
    .then(function(r) {
      if (!r.ok) throw new Error('Server error ' + r.status);
      return r.json();
    })
    .then(function() {
      closeEditCwModal();
      location.reload();
    })
    .catch(function(err) { alert('Could not save: ' + err.message); });
}

function deleteCw() {
  if (!editCwId) return;
  if (!confirm('Delete this coursework? This cannot be undone.')) return;

  fetch('/api/courseworks/' + editCwId, { method: 'DELETE' })
    .then(function(r) {
      if (!r.ok) throw new Error('Server error ' + r.status);
      return r.json();
    })
    .then(function() {
      closeEditCwModal();
      location.reload();
    })
    .catch(function(err) { alert('Could not delete: ' + err.message); });
}

// Close modals when clicking the backdrop
document.addEventListener('click', function(e) {
  var addModal      = document.getElementById('add-modal');
  var editModal     = document.getElementById('edit-modal');
  var createModal   = document.getElementById('create-modal');
  var semesterModal = document.getElementById('semester-modal');
  var addCwModal    = document.getElementById('add-cw-modal');
  var editCwModal   = document.getElementById('edit-cw-modal');
  if (e.target === addModal)      closeAddModal();
  if (e.target === editModal)     closeEditModal();
  if (e.target === createModal)   closeCreateModal();
  if (e.target === semesterModal) closeSemesterModal();
  if (e.target === addCwModal)    closeAddCwModal();
  if (e.target === editCwModal)   closeEditCwModal();
});

// ── Timetable PDF import ──────────────────────────────────────────────────────

(function() {
  var dropzone  = document.getElementById('timetable-dropzone');
  var fileInput = document.getElementById('timetable-file-input');
  var statusEl  = document.getElementById('import-status');
  if (!dropzone) return;

  dropzone.addEventListener('click', function() { fileInput.click(); });
  fileInput.addEventListener('change', function() {
    if (fileInput.files.length) handleTimetableFile(fileInput.files[0]);
  });
  dropzone.addEventListener('dragover', function(e) {
    e.preventDefault();
    dropzone.classList.add('dragover');
  });
  dropzone.addEventListener('dragleave', function() {
    dropzone.classList.remove('dragover');
  });
  dropzone.addEventListener('drop', function(e) {
    e.preventDefault();
    dropzone.classList.remove('dragover');
    var file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      handleTimetableFile(file);
    } else {
      showImportStatus('Please drop a PDF file.', 'error');
    }
  });

  function handleTimetableFile(file) {
  var label = document.getElementById('dropzone-label');

  label.textContent = 'Uploading PDF…';
  dropzone.classList.add('uploading');

  var formData = new FormData();
  formData.append('timetableFile', file);

  fetch('/api/timetable/import', {
    method: 'POST',
    body: formData
  })
    .then(function(r) {
      return r.json();
    })
    .then(function(data) {
      label.textContent = 'Drop timetable PDF here';
      dropzone.classList.remove('uploading');

      if (data.error) {
        showImportStatus(data.error, 'error');
      } else {
        showImportStatus(data.message, 'success');
        if (data.firstDate) {
          weekOffset = getWeekOffsetForDate(data.firstDate);
          updateWeekDisplay();
        }
        loadEntries();
      }
    })
    .catch(function(err) {
      console.error('Upload timetable error:', err);
      label.textContent = 'Drop timetable PDF here';
      dropzone.classList.remove('uploading');
      showImportStatus('Could not upload the timetable PDF.', 'error');
    });
}

  function showImportStatus(msg, type) {
    statusEl.textContent    = msg;
    statusEl.className      = 'import-status ' + type;
    statusEl.style.display  = 'block';
    setTimeout(function() { statusEl.style.display = 'none'; }, 5000);
  }
})();

// ── Helpers ───────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
