// models/Coursework.js
// Handles all database operations for the courseworks table.

var db = require('../db');

module.exports = {
  getByModule: async function(moduleCode) {
    var result = await db.query(
      'SELECT * FROM courseworks WHERE module_code = $1 ORDER BY due_date ASC',
      [moduleCode]
    );
    return result.rows;
  },

  create: async function(moduleCode, name, type, weighting, dueDate) {
    var result = await db.query(
      'INSERT INTO courseworks (module_code, name, type, weighting, due_date) ' +
      'VALUES ($1, $2, $3, $4, $5) RETURNING id',
      [moduleCode, name, type, weighting, dueDate]
    );
    return result.rows[0];
  },

  update: async function(id, name, type, weighting, dueDate) {
    await db.query(
      'UPDATE courseworks SET name=$1, type=$2, weighting=$3, due_date=$4 WHERE id=$5',
      [name, type, weighting, dueDate, id]
    );
  },

  delete: async function(id) {
    await db.query('DELETE FROM courseworks WHERE id=$1', [id]);
  },

  getById: async function(id) {
    var result = await db.query('SELECT * FROM courseworks WHERE id=$1', [id]);
    return result.rows[0];
  }
};
