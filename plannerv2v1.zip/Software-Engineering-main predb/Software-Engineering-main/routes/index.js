// index.js - all page routes and API endpoints

var express = require('express');
var router  = express.Router();
var multer  = require('multer');
var db      = require('../db');

var upload = multer({ storage: multer.memoryStorage() });

// ============================================================
// Auth middleware - redirects to /login if not logged in
// ============================================================
function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
}

// ============================================================
// HOME PAGE  GET /
// ============================================================
router.get('/', requireAuth, async function(req, res) {
  var userId = req.session.user.id;

  try {
    // Get modules the student is enrolled in
    var modulesResult = await db.query(
      'SELECT m.code, m.name FROM modules m JOIN enrolments e ON m.code = e.module_code WHERE e.user_id = $1 ORDER BY m.code',
      [userId]
    );

    // Get upcoming task deadlines (matches dashboard task IDs so ?open=id works)
    var deadlinesResult = await db.query(
      'SELECT t.id, t.title as name, t.due_date, ' +
      'COALESCE(t.module_code, c.module_code) as module_code ' +
      'FROM tasks t ' +
      'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
      'WHERE t.user_id = $1 AND t.due_date IS NOT NULL AND t.due_date >= CURRENT_DATE ' +
      'ORDER BY t.due_date ASC',
      [userId]
    );

    // Add "days left" and urgency colour to each deadline
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var deadlines = deadlinesResult.rows.map(function(d) {
      var due = new Date(d.due_date);
      due.setHours(0, 0, 0, 0);
      var daysLeft = Math.round((due - today) / 86400000);
      d.daysLeft = daysLeft;
      if (daysLeft < 7) {
        d.urgency = 'red';
      } else if (daysLeft < 14) {
        d.urgency = 'yellow';
      } else {
        d.urgency = 'green';
      }
      return d;
    });

    // Get to-do items for this user
    var todosResult = await db.query(
      'SELECT * FROM todos WHERE user_id = $1 ORDER BY id ASC',
      [userId]
    );

    // Get hours studied per day this week (Mon=1 to Sun=7)
    var weeklyResult = await db.query(
      "SELECT EXTRACT(ISODOW FROM date) AS dow, COALESCE(SUM(time_spent), 0) AS hours " +
      "FROM activities " +
      "WHERE user_id = $1 " +
      "AND date >= date_trunc('week', CURRENT_DATE) " +
      "AND date < date_trunc('week', CURRENT_DATE) + INTERVAL '7 days' " +
      "GROUP BY dow ORDER BY dow",
      [userId]
    );

    // Build a 7-element array Mon-Sun, default 0
    var weeklyHours = [0, 0, 0, 0, 0, 0, 0];
    weeklyResult.rows.forEach(function(r) {
      var idx = parseInt(r.dow) - 1; // ISODOW: Mon=1, Sun=7
      if (idx >= 0 && idx < 7) {
        weeklyHours[idx] = parseFloat(r.hours);
      }
    });

    var todayStr = new Date().toLocaleDateString('en-GB');

    res.render('home', {
      title:       'Study Planner',
      user:        req.session.user,
      modules:     modulesResult.rows,
      deadlines:   deadlines,
      todos:       todosResult.rows,
      weeklyHours: weeklyHours,
      today:       todayStr
    });

  } catch (err) {
    console.error('Home page error:', err);
    res.render('home', {
      title:       'Study Planner',
      user:        req.session.user,
      modules:     [],
      deadlines:   [],
      todos:       [],
      weeklyHours: [0, 0, 0, 0, 0, 0, 0],
      today:       new Date().toLocaleDateString('en-GB')
    });
  }
});

// ============================================================
// DASHBOARD PAGE  GET /dashboard
// ============================================================
router.get('/dashboard', requireAuth, function(req, res) {
  res.render('dashboard', {
    title: 'Study Dashboard',
    user:  req.session.user
  });
});

// ============================================================
// PLANNER PAGE  GET /planner
// ============================================================
router.get('/planner', requireAuth, async function(req, res) {
  var userId       = req.session.user.id;
  var timetableSem = req.session.timetableSem || 'WINTER';
  var flashError   = req.session.plannerError || null;
  req.session.plannerError = null;

  try {
    // All semester profiles for this user
    var semResult = await db.query(
      'SELECT s.id, s.name, s.created_at FROM semesters s WHERE s.user_id = $1 ORDER BY s.created_at DESC',
      [userId]
    );
    var semesters = semResult.rows;

    // Active semester: last in session, or first in DB, or null
    var activeSemesterId = req.session.activeSemesterId || null;
    var activeSemester   = null;
    if (semesters.length > 0) {
      if (activeSemesterId) {
        activeSemester = semesters.find(function(s) { return s.id === activeSemesterId; }) || semesters[0];
      } else {
        activeSemester = semesters[0];
      }
      req.session.activeSemesterId = activeSemester.id;
    }

    // Modules for the active semester
    var semesterModules = [];
    if (activeSemester) {
      var smResult = await db.query(
        'SELECT m.code, m.name, ' +
        '(SELECT COUNT(*) FROM courseworks c WHERE c.module_code = m.code) as coursework_count ' +
        'FROM modules m ' +
        'JOIN semester_modules sm ON m.code = sm.module_code ' +
        'WHERE sm.semester_id = $1 ' +
        'ORDER BY m.code',
        [activeSemester.id]
      );
      semesterModules = smResult.rows;
    }

    res.render('planner', {
      title:           'Study Planner',
      user:            req.session.user,
      semesters:       semesters,
      activeSemester:  activeSemester,
      semesterModules: semesterModules,
      flashError:      flashError
    });

  } catch (err) {
    console.error('Planner page error:', err);
    res.render('planner', {
      title:           'Study Planner',
      user:            req.session.user,
      semesters:       [],
      activeSemester:  null,
      semesterModules: [],
      flashError:      null
    });
  }
});

// ============================================================
// CREATE SEMESTER PROFILE  POST /planner/create-profile
// ============================================================
router.post('/planner/create-profile', requireAuth, upload.single('semesterFile'), async function(req, res) {
  var userId         = req.session.user.id;
  var profileName    = (req.body.profileName    || '').trim();
  var moduleName     = (req.body.moduleName     || '').trim();
  var courseworkName = (req.body.courseworkName || '').trim();
  var courseworkType = req.body.courseworkType  || 'coursework';
  var weighting      = parseInt(req.body.weighting) || null;
  var dueDate        = req.body.dueDate         || null;

  if (!profileName || !courseworkName || !dueDate) {
    req.session.plannerError = 'Please fill in profile name, coursework name, and due date.';
    return res.redirect('/planner');
  }
  if (!req.file) {
    req.session.plannerError = 'Please upload a coursework file.';
    return res.redirect('/planner');
  }

  // Extract module code from filename, e.g. "CMP-5037B-VoIP-assignment.pdf" → "CMP-5037B"
  var filename    = req.file.originalname;
  var codeMatch   = filename.match(/([A-Z]+-\d+[A-Z]*)/i);
  var moduleCode  = codeMatch ? codeMatch[1].toUpperCase() : null;

  if (!moduleCode) {
    req.session.plannerError = 'Could not read module code from filename. Rename it to start with e.g. CMP-5037B-...';
    return res.redirect('/planner');
  }

  var finalModuleName = moduleName || moduleCode;

  try {
    // Create the semester profile
    var semResult = await db.query(
      'INSERT INTO semesters (user_id, name) VALUES ($1, $2) RETURNING id',
      [userId, profileName]
    );
    var semesterId = semResult.rows[0].id;

    // Upsert module and link to user + semester
    await db.query(
      'INSERT INTO modules (code, name) VALUES ($1, $2) ON CONFLICT (code) DO NOTHING',
      [moduleCode, finalModuleName]
    );
    await db.query(
      'INSERT INTO enrolments (user_id, module_code) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [userId, moduleCode]
    );
    await db.query(
      'INSERT INTO semester_modules (semester_id, module_code) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [semesterId, moduleCode]
    );

    // Insert coursework
    await db.query(
      'INSERT INTO courseworks (module_code, name, type, weighting, due_date) VALUES ($1, $2, $3, $4, $5)',
      [moduleCode, courseworkName, courseworkType, weighting, dueDate]
    );

    // Auto-create a timetable entry on the due date
    await db.query(
      'INSERT INTO timetable_entries (user_id, entry_date, start_time, end_time, description) VALUES ($1, $2, $3, $4, $5)',
      [userId, dueDate, '09:00', '10:00', courseworkName + ' (' + moduleCode + ')']
    );

    req.session.activeSemesterId = semesterId;
    res.redirect('/planner');

  } catch (err) {
    console.error('Create profile error:', err);
    req.session.plannerError = 'Something went wrong saving the profile. Please try again.';
    res.redirect('/planner');
  }
});

// ============================================================
// SWITCH ACTIVE SEMESTER  POST /planner/switch
// ============================================================
router.post('/planner/switch', requireAuth, async function(req, res) {
  var userId     = req.session.user.id;
  var semesterId = parseInt(req.body.semesterId);

  try {
    // Verify this semester belongs to the user
    var check = await db.query(
      'SELECT id FROM semesters WHERE id = $1 AND user_id = $2',
      [semesterId, userId]
    );
    if (check.rows.length > 0) {
      req.session.activeSemesterId = semesterId;
    }
  } catch (err) {
    console.error('Switch semester error:', err);
  }
  res.redirect('/planner');
});

// ============================================================
// MODULE PAGE  GET /module?module=CMP-5012B
// ============================================================
router.get('/module', requireAuth, async function(req, res) {
  var userId         = req.session.user.id;
  var selectedModule = req.query.module || '';

  try {
    // All modules this student is enrolled in (for the dropdown)
    var modulesResult = await db.query(
      'SELECT m.code, m.name FROM modules m JOIN enrolments e ON m.code = e.module_code WHERE e.user_id = $1 ORDER BY m.code',
      [userId]
    );

    var tasks       = [];
    var milestones  = [];
    var courseworks = [];

    if (selectedModule) {
      // Tasks for this module (via coursework join OR direct module_code)
      var tasksResult = await db.query(
        'SELECT t.*, c.name as coursework_name ' +
        'FROM tasks t ' +
        'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
        'WHERE t.user_id = $1 AND (c.module_code = $2 OR t.module_code = $2) ' +
        'ORDER BY COALESCE(t.start_week, 99) ASC',
        [userId, selectedModule]
      );
      tasks = tasksResult.rows;

      // Milestones for those tasks
      if (tasks.length > 0) {
        var taskIds = tasks.map(function(t) { return t.id; });
        var placeholders = taskIds.map(function(id, i) { return '$' + (i + 1); }).join(', ');
        var milestoneResult = await db.query(
          'SELECT mil.*, t.title as task_title FROM milestones mil ' +
          'JOIN tasks t ON mil.task_id = t.id ' +
          'WHERE mil.task_id IN (' + placeholders + ') ' +
          'ORDER BY mil.deadline ASC NULLS LAST',
          taskIds
        );
        milestones = milestoneResult.rows;
      }

      // Courseworks for this module (for activities & deadlines panel)
      var cwResult = await db.query(
        'SELECT * FROM courseworks WHERE module_code = $1 ORDER BY due_date ASC',
        [selectedModule]
      );
      courseworks = cwResult.rows;
    }

    res.render('module', {
      title:          'Module Page',
      user:           req.session.user,
      selectedModule: selectedModule,
      allModules:     modulesResult.rows,
      tasks:          tasks,
      milestones:     milestones,
      courseworks:    courseworks
    });

  } catch (err) {
    console.error('Module page error:', err);
    res.render('module', {
      title:          'Module Page',
      user:           req.session.user,
      selectedModule: selectedModule,
      allModules:     [],
      tasks:          [],
      milestones:     [],
      courseworks:    []
    });
  }
});

// ============================================================
// TO-DO LIST ACTIONS (form POST, redirect back to home)
// ============================================================

router.post('/todos', requireAuth, async function(req, res) {
  var text = (req.body.text || '').trim();
  if (text) {
    try {
      await db.query('INSERT INTO todos (user_id, text) VALUES ($1, $2)', [req.session.user.id, text]);
    } catch (err) {
      console.error('Add todo error:', err);
    }
  }
  res.redirect('/');
});

router.post('/todos/:id/toggle', requireAuth, async function(req, res) {
  try {
    await db.query(
      'UPDATE todos SET done = NOT done WHERE id = $1 AND user_id = $2',
      [req.params.id, req.session.user.id]
    );
  } catch (err) {
    console.error('Toggle todo error:', err);
  }
  res.redirect('/');
});

router.post('/todos/:id/delete', requireAuth, async function(req, res) {
  try {
    await db.query('DELETE FROM todos WHERE id = $1 AND user_id = $2', [req.params.id, req.session.user.id]);
  } catch (err) {
    console.error('Delete todo error:', err);
  }
  res.redirect('/');
});

// ============================================================
// SEMESTER FILE UPLOAD  POST /upload
// ============================================================
router.post('/upload', requireAuth, upload.single('semesterFile'), async function(req, res) {
  if (!req.file) {
    return res.redirect('/');
  }

  var content = req.file.buffer.toString('utf8');
  var lines   = content.split('\n');
  var currentModuleCode = null;

  try {
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) continue;

      if (line.startsWith('MODULE:')) {
        var parts = line.replace('MODULE:', '').split('|');
        if (parts.length >= 2) {
          currentModuleCode = parts[0].trim();
          var moduleName    = parts[1].trim();
          await db.query(
            'INSERT INTO modules (code, name) VALUES ($1, $2) ON CONFLICT (code) DO NOTHING',
            [currentModuleCode, moduleName]
          );
          await db.query(
            'INSERT INTO enrolments (user_id, module_code) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [req.session.user.id, currentModuleCode]
          );
        }
      } else if ((line.startsWith('COURSEWORK:') || line.startsWith('EXAM:')) && currentModuleCode) {
        var type    = line.startsWith('EXAM:') ? 'exam' : 'coursework';
        var payload = line.replace('COURSEWORK:', '').replace('EXAM:', '').split('|');
        if (payload.length >= 3) {
          var cwName    = payload[0].trim();
          var weighting = parseInt(payload[1].trim()) || null;
          var dueDate   = payload[2].trim();
          await db.query(
            'INSERT INTO courseworks (module_code, name, type, weighting, due_date) VALUES ($1, $2, $3, $4, $5)',
            [currentModuleCode, cwName, type, weighting, dueDate]
          );
        }
      }
    }
  } catch (err) {
    console.error('Upload parse error:', err);
  }

  res.redirect('/');
});

// ============================================================
// API: MODULES (used by dashboard module dropdown)
// ============================================================

router.get('/api/modules', requireAuth, async function(req, res) {
  var userId = req.session.user.id;
  try {
    var result = await db.query(
      'SELECT m.code, m.name FROM modules m JOIN enrolments e ON m.code = e.module_code WHERE e.user_id = $1 ORDER BY m.code',
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('GET /api/modules error:', err);
    res.status(500).json({ error: 'Could not load modules' });
  }
});

// ============================================================
// API: TASKS  (used by dashboard.js via fetch)
// ============================================================

router.get('/api/tasks', requireAuth, async function(req, res) {
  var userId = req.session.user.id;
  try {
    var tasksResult = await db.query(
      'SELECT t.*, c.name as coursework_name, ' +
      'COALESCE(t.module_code, c.module_code) as module_code ' +
      'FROM tasks t ' +
      'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
      'WHERE t.user_id = $1 ' +
      'ORDER BY t.created_at ASC',
      [userId]
    );
    var tasks = tasksResult.rows;

    var milResult = await db.query(
      'SELECT * FROM milestones WHERE task_id IN (SELECT id FROM tasks WHERE user_id = $1) ORDER BY start_week ASC',
      [userId]
    );

    tasks.forEach(function(task) {
      task.milestones = milResult.rows.filter(function(m) {
        return m.task_id === task.id;
      });
    });

    res.json(tasks);
  } catch (err) {
    console.error('GET /api/tasks error:', err);
    res.status(500).json({ error: 'Could not load tasks' });
  }
});

router.post('/api/tasks', requireAuth, async function(req, res) {
  var userId  = req.session.user.id;
  var title   = req.body.title   || 'New Task';
  var dueDate = req.body.dueDate || null;

  try {
    var result = await db.query(
      'INSERT INTO tasks (user_id, title, due_date) VALUES ($1, $2, $3) RETURNING *',
      [userId, title, dueDate]
    );
    var task = result.rows[0];
    task.milestones = [];
    res.json(task);
  } catch (err) {
    console.error('POST /api/tasks error:', err);
    res.status(500).json({ error: 'Could not create task' });
  }
});

router.put('/api/tasks/:id', requireAuth, async function(req, res) {
  var userId     = req.session.user.id;
  var taskId     = req.params.id;
  var title      = req.body.title;
  var dueDate    = req.body.dueDate    || null;
  var moduleCode = req.body.moduleCode || null;

  try {
    await db.query(
      'UPDATE tasks SET title = $1, due_date = $2, module_code = $3 WHERE id = $4 AND user_id = $5',
      [title, dueDate, moduleCode, taskId, userId]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/tasks/:id error:', err);
    res.status(500).json({ error: 'Could not update task' });
  }
});

router.delete('/api/tasks/:id', requireAuth, async function(req, res) {
  var userId = req.session.user.id;
  var taskId = req.params.id;

  try {
    await db.query('DELETE FROM tasks WHERE id = $1 AND user_id = $2', [taskId, userId]);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/tasks/:id error:', err);
    res.status(500).json({ error: 'Could not delete task' });
  }
});

// ============================================================
// API: MILESTONES
// ============================================================

router.post('/api/milestones', requireAuth, async function(req, res) {
  var userId    = req.session.user.id;
  var taskId    = req.body.taskId;
  var name      = req.body.name;
  var startWeek = parseInt(req.body.startWeek) || 1;
  var endWeek   = parseInt(req.body.endWeek)   || 1;

  try {
    var check = await db.query('SELECT id FROM tasks WHERE id = $1 AND user_id = $2', [taskId, userId]);
    if (check.rows.length === 0) {
      return res.status(403).json({ error: 'Not allowed' });
    }
    var result = await db.query(
      'INSERT INTO milestones (task_id, name, start_week, end_week) VALUES ($1, $2, $3, $4) RETURNING *',
      [taskId, name, startWeek, endWeek]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('POST /api/milestones error:', err);
    res.status(500).json({ error: 'Could not add milestone' });
  }
});

router.put('/api/milestones/:id', requireAuth, async function(req, res) {
  var userId      = req.session.user.id;
  var milestoneId = req.params.id;

  try {
    await db.query(
      'UPDATE milestones SET done = NOT done WHERE id = $1 AND task_id IN (SELECT id FROM tasks WHERE user_id = $2)',
      [milestoneId, userId]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/milestones/:id error:', err);
    res.status(500).json({ error: 'Could not update milestone' });
  }
});

router.delete('/api/milestones/:id', requireAuth, async function(req, res) {
  var userId      = req.session.user.id;
  var milestoneId = req.params.id;

  try {
    await db.query(
      'DELETE FROM milestones WHERE id = $1 AND task_id IN (SELECT id FROM tasks WHERE user_id = $2)',
      [milestoneId, userId]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/milestones/:id error:', err);
    res.status(500).json({ error: 'Could not delete milestone' });
  }
});

// ============================================================
// API: TIMETABLE
// ============================================================

// GET /api/timetable?weekStart=YYYY-MM-DD  — returns entries for that Mon-Sun
router.get('/api/timetable', requireAuth, async function(req, res) {
  var userId    = req.session.user.id;
  var weekStart = req.query.weekStart;
  if (!weekStart) {
    return res.status(400).json({ error: 'weekStart required' });
  }
  try {
    var result = await db.query(
      'SELECT * FROM timetable_entries WHERE user_id = $1 AND entry_date >= $2 AND entry_date <= ($2::date + 6) ORDER BY entry_date, start_time',
      [userId, weekStart]
    );
    res.json(result.rows);
  } catch (err) {
    console.error('GET /api/timetable error:', err);
    res.status(500).json({ error: 'Could not load timetable' });
  }
});

// POST /api/timetable  — create a new entry
router.post('/api/timetable', requireAuth, async function(req, res) {
  var userId      = req.session.user.id;
  var entryDate   = req.body.entryDate;
  var startTime   = req.body.startTime;
  var endTime     = req.body.endTime;
  var description = req.body.description || '';

  try {
    var result = await db.query(
      'INSERT INTO timetable_entries (user_id, entry_date, start_time, end_time, description) VALUES ($1, $2, $3, $4, $5) RETURNING *',
      [userId, entryDate, startTime, endTime, description]
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error('POST /api/timetable error:', err);
    res.status(500).json({ error: 'Could not save timetable entry' });
  }
});

// PUT /api/timetable/:id  — update an entry
router.put('/api/timetable/:id', requireAuth, async function(req, res) {
  var userId      = req.session.user.id;
  var entryId     = req.params.id;
  var entryDate   = req.body.entryDate;
  var startTime   = req.body.startTime;
  var endTime     = req.body.endTime;
  var description = req.body.description || '';

  try {
    await db.query(
      'UPDATE timetable_entries SET entry_date = $1, start_time = $2, end_time = $3, description = $4 WHERE id = $5 AND user_id = $6',
      [entryDate, startTime, endTime, description, entryId, userId]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/timetable/:id error:', err);
    res.status(500).json({ error: 'Could not update timetable entry' });
  }
});

// DELETE /api/timetable/:id
router.delete('/api/timetable/:id', requireAuth, async function(req, res) {
  var userId  = req.session.user.id;
  var entryId = req.params.id;

  try {
    await db.query('DELETE FROM timetable_entries WHERE id = $1 AND user_id = $2', [entryId, userId]);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/timetable/:id error:', err);
    res.status(500).json({ error: 'Could not delete timetable entry' });
  }
});

module.exports = router;
