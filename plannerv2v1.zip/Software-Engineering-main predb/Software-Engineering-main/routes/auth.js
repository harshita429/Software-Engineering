// auth.js - handles login and logout

var express = require('express');
var router  = express.Router();
var bcrypt  = require('bcryptjs');
var db      = require('../db');

// GET /login - show the login page
router.get('/login', function(req, res) {
  if (req.session.user) {
    return res.redirect('/');
  }
  res.render('login', {
    title: 'Login',
    error: null
  });
});

// POST /login - check username and password
router.post('/login', async function(req, res) {
  var username = req.body.username;
  var password = req.body.password;

  if (!username || !password) {
    return res.render('login', {
      title: 'Login',
      error: 'Please enter your username and password.'
    });
  }

  try {
    var result = await db.query('SELECT * FROM users WHERE username = $1', [username]);
    var user = result.rows[0];

    if (!user) {
      return res.render('login', {
        title: 'Login',
        error: 'Username or password is incorrect.'
      });
    }

    var passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.render('login', {
        title: 'Login',
        error: 'Username or password is incorrect.'
      });
    }

    // Save user info in the session
    req.session.user = {
      id:       user.id,
      name:     user.name,
      username: user.username
    };

    res.redirect('/');

  } catch (err) {
    console.error('Login error:', err);
    res.render('login', {
      title: 'Login',
      error: 'Something went wrong. Please try again.'
    });
  }
});

// POST /logout - clear session and redirect to login
router.post('/logout', function(req, res) {
  req.session.destroy(function() {
    res.redirect('/login');
  });
});

module.exports = router;
