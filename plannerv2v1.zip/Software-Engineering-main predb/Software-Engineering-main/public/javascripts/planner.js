// planner.js
// Handles the weekly timetable grid with week navigation.
// Entries are stored in the database via the server API.

var weekOffset   = 0;  // 0 = current week, -1 = last week, +1 = next week
var editEntryId  = null;
var dayNames     = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

document.addEventListener('DOMContentLoaded', function() {
  updateWeekDisplay();
  loadEntries();
});

// ── Week helpers ──────────────────────────────────────────────────────────────

function getMondayDate(offset) {
  var d   = new Date();
  var day = d.getDay();                        // 0=Sun, 1=Mon ... 6=Sat
  var diff = (day === 0) ? -6 : 1 - day;      // days back to Monday
  d.setDate(d.getDate() + diff + (offset * 7));
  d.setHours(0, 0, 0, 0);
  return d;
}

function pad(n) {
  return n < 10 ? '0' + n : '' + n;
}

function formatDate(d) {
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
}

function formatDateShort(d) {
  return pad(d.getDate()) + '/' + pad(d.getMonth() + 1);
}

function updateWeekDisplay() {
  var monday = getMondayDate(weekOffset);
  var sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  // Update week label
  document.getElementById('week-label').textContent =
    formatDateShort(monday) + ' — ' + formatDateShort(sunday);

  // Update column headers with actual dates
  var headers = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  var dayLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  for (var i = 0; i < 7; i++) {
    var headerEl = document.getElementById('header-' + headers[i]);
    if (headerEl) {
      var d = new Date(monday);
      d.setDate(monday.getDate() + i);
      headerEl.textContent = dayLabels[i] + ' ' + formatDateShort(d);
    }
  }
}

// ── Load entries for current week ─────────────────────────────────────────────

function loadEntries() {
  var monday     = getMondayDate(weekOffset);
  var weekStart  = formatDate(monday);

  // Clear all cells first
  var cells = document.querySelectorAll('.planner-cell');
  for (var i = 0; i < cells.length; i++) {
    cells[i].innerHTML = '';
  }

  fetch('/api/timetable?weekStart=' + weekStart)
    .then(function(res) { return res.json(); })
    .then(function(entries) {
      entries.forEach(function(entry) {
        placeEntry(entry, monday);
      });
    })
    .catch(function(err) { console.error('Load timetable error:', err); });
}

function placeEntry(entry, monday) {
  // Work out which column (day 0=Mon ... 6=Sun)
  // entry_date may be a "YYYY-MM-DD" string or a Date object depending on pg version
  var raw = entry.entry_date;
  var entryDate;
  if (raw instanceof Date) {
    entryDate = new Date(raw.getFullYear(), raw.getMonth(), raw.getDate());
  } else {
    var parts = String(raw).substring(0, 10).split('-');
    entryDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
  }
  var dayIndex = Math.round((entryDate - monday) / 86400000);
  if (dayIndex < 0 || dayIndex > 6) return;

  // Work out which row (hour)
  var startHour = parseInt(String(entry.start_time).substring(0, 2), 10);

  var cell = document.querySelector('[data-day="' + dayIndex + '"][data-hour="' + startHour + '"]');
  if (!cell) return;

  var block = document.createElement('div');
  block.className = 'entry-block';
  block.innerHTML =
    '<span class="entry-time">' + escapeHtml(entry.start_time.substring(0, 5)) + '–' + escapeHtml(entry.end_time.substring(0, 5)) + '</span>' +
    '<span class="entry-desc">' + escapeHtml(entry.description) + '</span>';

  (function(e) {
    block.addEventListener('click', function(ev) {
      ev.stopPropagation();
      openEditModal(e);
    });
  })(entry);

  cell.appendChild(block);
}

// ── Week navigation ───────────────────────────────────────────────────────────

function prevWeek() {
  weekOffset--;
  updateWeekDisplay();
  loadEntries();
}

function nextWeek() {
  weekOffset++;
  updateWeekDisplay();
  loadEntries();
}

// ── Add entry modal ───────────────────────────────────────────────────────────

function openAddModal() {
  // Default date to Monday of current week
  var monday = getMondayDate(weekOffset);
  document.getElementById('add-date').value  = formatDate(monday);
  document.getElementById('add-start').value = '09:00';
  document.getElementById('add-end').value   = '10:00';
  document.getElementById('add-desc').value  = '';
  document.getElementById('add-modal').style.display = 'flex';
}

function closeAddModal() {
  document.getElementById('add-modal').style.display = 'none';
}

function saveNewEntry() {
  var entryDate = document.getElementById('add-date').value;
  var startTime = document.getElementById('add-start').value;
  var endTime   = document.getElementById('add-end').value;
  var desc      = document.getElementById('add-desc').value.trim();

  if (!entryDate || !startTime || !endTime) {
    alert('Please fill in the date and times.');
    return;
  }
  if (endTime <= startTime) {
    alert('End time must be after start time.');
    return;
  }

  fetch('/api/timetable', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ entryDate: entryDate, startTime: startTime, endTime: endTime, description: desc })
  })
    .then(function(res) {
      if (!res.ok) { throw new Error('Server error ' + res.status); }
      return res.json();
    })
    .then(function() {
      closeAddModal();
      loadEntries();
    })
    .catch(function(err) {
      console.error('Save entry error:', err);
      alert('Could not save entry: ' + err.message);
    });
}

// ── Edit entry modal ──────────────────────────────────────────────────────────

function openEditModal(entry) {
  editEntryId = entry.id;
  document.getElementById('edit-date').value  = entry.entry_date.substring(0, 10);
  document.getElementById('edit-start').value = entry.start_time.substring(0, 5);
  document.getElementById('edit-end').value   = entry.end_time.substring(0, 5);
  document.getElementById('edit-desc').value  = entry.description;
  document.getElementById('edit-modal').style.display = 'flex';
}

function closeEditModal() {
  editEntryId = null;
  document.getElementById('edit-modal').style.display = 'none';
}

function saveEditEntry() {
  if (!editEntryId) return;

  var entryDate = document.getElementById('edit-date').value;
  var startTime = document.getElementById('edit-start').value;
  var endTime   = document.getElementById('edit-end').value;
  var desc      = document.getElementById('edit-desc').value.trim();

  if (!entryDate || !startTime || !endTime) {
    alert('Please fill in the date and times.');
    return;
  }

  fetch('/api/timetable/' + editEntryId, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ entryDate: entryDate, startTime: startTime, endTime: endTime, description: desc })
  })
    .then(function() {
      closeEditModal();
      loadEntries();
    })
    .catch(function(err) { console.error('Update entry error:', err); });
}

function deleteEntry() {
  if (!editEntryId) return;
  fetch('/api/timetable/' + editEntryId, { method: 'DELETE' })
    .then(function() {
      closeEditModal();
      loadEntries();
    })
    .catch(function(err) { console.error('Delete entry error:', err); });
}

// ── Semester profile modals ───────────────────────────────────────────────────

function openCreateModal() {
  document.getElementById('create-modal').style.display = 'flex';
}

function closeCreateModal() {
  document.getElementById('create-modal').style.display = 'none';
}

// Close modals when clicking the backdrop
document.addEventListener('click', function(e) {
  var addModal    = document.getElementById('add-modal');
  var editModal   = document.getElementById('edit-modal');
  var createModal = document.getElementById('create-modal');
  if (e.target === addModal)    closeAddModal();
  if (e.target === editModal)   closeEditModal();
  if (e.target === createModal) closeCreateModal();
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
