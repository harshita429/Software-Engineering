require('dotenv').config();

var express = require('express');
var path    = require('path');
var session = require('express-session');

var indexRouter = require('./routes/index');
var authRouter  = require('./routes/auth');

var app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'dev_secret',
  resave: false,
  saveUninitialized: false
}));

app.use('/', authRouter);
app.use('/', indexRouter);

var port = process.env.PORT || 3000;
app.listen(port, function() {
  console.log('Server running at http://localhost:' + port);
});
