var MONTH_MAP = {
  january: '01', february: '02', march: '03', april: '04',
  may: '05', june: '06', july: '07', august: '08',
  september: '09', october: '10', november: '11', december: '12'
};

function toISODate(dayStr, monthStr, yearStr) {
  var m = MONTH_MAP[monthStr.toLowerCase()];
  if (!m) return null;
  return yearStr + '-' + m + '-' + dayStr.padStart(2, '0');
}

function parseCourseworkPDF(text) {
  var flat = text.replace(/\r/g, ' ').replace(/\n/g, ' ').replace(/\s+/g, ' ').trim();
  console.log('PDF TEXT (first 3000 chars):', flat.substring(0, 3000));

  var modMatch = flat.match(
    /Module:\s*[A-Z]+-\d+[A-Z]?\s+(.+?)(?=\s+(?:Assignment|Coordinator|School|Level|Credit|Value|Date))/i
  );
  var moduleName = modMatch ? modMatch[1].trim() : null;

  var assignMatch = flat.match(/Assignment:\s*(.+?)(?=\s+(?:Value|Date|Coordinator|School|Level|Credit))/i);
  var assignmentName = assignMatch ? assignMatch[1].trim() : 'Coursework';

  var setMatch = flat.match(
    /Date set:\s*(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})/i
  );
  var startDate = setMatch ? toISODate(setMatch[1], setMatch[2], setMatch[3]) : null;

  var MONTHS = 'January|February|March|April|May|June|July|August|September|October|November|December';
  var DAYS   = 'Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday';
  var dateRe = new RegExp(
    '(?:Date due:\\s*)?(?:' + DAYS + ')\\s+(\\d{1,2})\\s+(' + MONTHS + ')\\s+(\\d{4})',
    'gi'
  );

  var dateHits = [];
  var dm;
  while ((dm = dateRe.exec(flat)) !== null) {
    var isoDate = toISODate(dm[1], dm[2], dm[3]);
    if (isoDate) dateHits.push({ date: isoDate, end: dm.index + dm[0].length });
  }

  var items = [];
  for (var i = 0; i < dateHits.length; i++) {
    var segStart = dateHits[i].end;
    var segEnd   = (i + 1 < dateHits.length) ? dateHits[i + 1].end : flat.length;
    var segment  = flat.substring(segStart, Math.min(segStart + 500, segEnd));

    var pctMatch = segment.match(/([A-Za-z][^(]{5,120})\s*\((\d{1,3})%\)/);
    if (pctMatch) {
      items.push({
        name:      pctMatch[1].trim(),
        weighting: parseInt(pctMatch[2], 10),
        dueDate:   dateHits[i].date,
        startDate: startDate
      });
    } else {
      items.push({
        name:      assignmentName,
        weighting: null,
        dueDate:   dateHits[i].date,
        startDate: startDate
      });
    }
  }

  return { moduleName: moduleName, items: items };
}

module.exports = parseCourseworkPDF;
