// controllers/uploadController.js
// Handles the legacy plain-text file upload that bulk-imports modules and courseworks.

var Module     = require('../models/Module');
var Coursework = require('../models/Coursework');

exports.handleUpload = async function(req, res) {
  if (!req.file) {
    return res.redirect('/');
  }

  var content = req.file.buffer.toString('utf8');
  var lines   = content.split('\n');
  var currentModuleCode = null;

  try {
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (!line) continue;

      if (line.startsWith('MODULE:')) {
        var parts = line.replace('MODULE:', '').split('|');
        if (parts.length >= 2) {
          currentModuleCode = parts[0].trim();
          var moduleName    = parts[1].trim();
          await Module.upsert(currentModuleCode, moduleName);
          await Module.enrol(req.session.user.id, currentModuleCode);
        }

      } else if ((line.startsWith('COURSEWORK:') || line.startsWith('EXAM:')) && currentModuleCode) {
        var type    = line.startsWith('EXAM:') ? 'exam' : 'coursework';
        var payload = line.replace('COURSEWORK:', '').replace('EXAM:', '').split('|');
        if (payload.length >= 3) {
          var cwName    = payload[0].trim();
          var weighting = parseInt(payload[1].trim()) || null;
          var dueDate   = payload[2].trim();
          await Coursework.create(currentModuleCode, cwName, type, weighting, dueDate);
        }
      }
    }
  } catch (err) {
    console.error('Upload parse error:', err);
  }

  res.redirect('/');
};
