// routes/auth.js
// Thin router — maps auth URLs to authController.

var express        = require('express');
var router         = express.Router();
var authController = require('../controllers/authController');

router.get('/login',  authController.showLogin);
router.post('/login', authController.login);
router.post('/logout', authController.logout);

module.exports = router;
