// db.js - sets up the connection to the PostgreSQL database
// We use a "pool" which keeps a few connections open and reuses them,
// instead of opening a new connection for every query (which would be slow).

var pg = require('pg');
require('dotenv').config();

var pool = new pg.Pool({
  host:     process.env.DB_HOST,
  port:     process.env.DB_PORT,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

pool.on('error', function(err) {
  console.error('Database error:', err);
});

// query() is the only thing the rest of the app needs.
// Always use $1, $2, ... placeholders instead of putting values
// directly in the SQL string - this prevents SQL injection attacks.
module.exports = {
  query: function(text, params) {
    return pool.query(text, params);
  }
};
