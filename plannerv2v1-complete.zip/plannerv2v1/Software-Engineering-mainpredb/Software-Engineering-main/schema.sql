-- ============================================================
-- schema.sql
-- Run this once to set up the database from scratch.
-- Creates all tables then inserts demo seed data.
-- Usage: psql -U postgres -d study_planner -f schema.sql
-- ============================================================

-- Drop tables in reverse dependency order so we can re-run cleanly
DROP TABLE IF EXISTS todos              CASCADE;
DROP TABLE IF EXISTS activity_tasks    CASCADE;
DROP TABLE IF EXISTS activities        CASCADE;
DROP TABLE IF EXISTS milestones        CASCADE;
DROP TABLE IF EXISTS task_dependencies CASCADE;
DROP TABLE IF EXISTS tasks             CASCADE;
DROP TABLE IF EXISTS courseworks       CASCADE;
DROP TABLE IF EXISTS semester_modules  CASCADE;
DROP TABLE IF EXISTS semesters         CASCADE;
DROP TABLE IF EXISTS enrolments        CASCADE;
DROP TABLE IF EXISTS modules           CASCADE;
DROP TABLE IF EXISTS timetable_entries CASCADE;
DROP TABLE IF EXISTS users             CASCADE;

-- ============================================================
-- TABLES
-- ============================================================

CREATE TABLE users (
  id            SERIAL       PRIMARY KEY,
  username      VARCHAR(50)  UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name          VARCHAR(100) NOT NULL
);

CREATE TABLE modules (
  code VARCHAR(20)  PRIMARY KEY,
  name VARCHAR(150) NOT NULL
);

-- Which modules a student is enrolled in
CREATE TABLE enrolments (
  user_id     INTEGER     NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
  module_code VARCHAR(20) NOT NULL REFERENCES modules(code) ON DELETE CASCADE,
  PRIMARY KEY (user_id, module_code)
);

-- Named semester study profiles (must come before courseworks)
CREATE TABLE semesters (
  id         SERIAL       PRIMARY KEY,
  user_id    INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name       VARCHAR(100) NOT NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Modules included in each semester profile
CREATE TABLE semester_modules (
  semester_id INTEGER     NOT NULL REFERENCES semesters(id) ON DELETE CASCADE,
  module_code VARCHAR(20) NOT NULL REFERENCES modules(code) ON DELETE CASCADE,
  PRIMARY KEY (semester_id, module_code)
);

-- Courseworks and exams for each module, scoped to a semester profile
CREATE TABLE courseworks (
  id          SERIAL       PRIMARY KEY,
  semester_id INTEGER      NOT NULL REFERENCES semesters(id) ON DELETE CASCADE,
  module_code VARCHAR(20)  NOT NULL REFERENCES modules(code) ON DELETE CASCADE,
  name        VARCHAR(200) NOT NULL,
  type        VARCHAR(20)  NOT NULL DEFAULT 'coursework',
  weighting   INTEGER,
  due_date    DATE         NOT NULL
);

-- Study tasks created by the student
CREATE TABLE tasks (
  id            SERIAL       PRIMARY KEY,
  user_id       INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  coursework_id INTEGER      REFERENCES courseworks(id) ON DELETE SET NULL,
  title         VARCHAR(200) NOT NULL,
  module_code   VARCHAR(20)  REFERENCES modules(code) ON DELETE SET NULL,
  start_week    INTEGER,
  end_week      INTEGER,
  due_date      DATE,
  created_at    TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Milestones belong to a task and appear on the Gantt chart
CREATE TABLE milestones (
  id         SERIAL       PRIMARY KEY,
  task_id    INTEGER      NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  name       VARCHAR(200) NOT NULL,
  start_week INTEGER      NOT NULL DEFAULT 1,
  end_week   INTEGER      NOT NULL DEFAULT 1,
  done       BOOLEAN      NOT NULL DEFAULT FALSE,
  deadline   DATE
);

-- Study activities (hours logged per day, used for the weekly productivity chart)
CREATE TABLE activities (
  id         SERIAL   PRIMARY KEY,
  user_id    INTEGER  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date       DATE     NOT NULL DEFAULT CURRENT_DATE,
  time_spent NUMERIC(5,1)
);

-- Timetable entries: each is a specific date + time range
CREATE TABLE timetable_entries (
  id          SERIAL   PRIMARY KEY,
  user_id     INTEGER  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  entry_date  DATE     NOT NULL,
  start_time  TIME     NOT NULL,
  end_time    TIME     NOT NULL,
  description TEXT     NOT NULL DEFAULT ''
);

-- Simple to-do list on the home page
CREATE TABLE todos (
  id      SERIAL       PRIMARY KEY,
  user_id INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  text    VARCHAR(300) NOT NULL,
  done    BOOLEAN      NOT NULL DEFAULT FALSE
);

-- ============================================================
-- SEED DATA
-- ============================================================

-- One demo student: username=student, password=password123
-- The hash below is bcrypt of "password123" (cost factor 10)
INSERT INTO users (username, password_hash, name) VALUES
  ('student', '$2b$10$60EZr39lGQxy4oYg6DEA3O2qE9BKYfhjXSuM8AhUUFCnk8FuzLOuq', 'Alex Carter');

-- Three modules
INSERT INTO modules (code, name) VALUES
  ('CMP-5012B', 'Software Engineering'),
  ('CMP-5013A', 'Architectures and Operating Systems'),
  ('CMP-5036A', 'Information Retrieval');

-- Enrol the demo student in all three modules
INSERT INTO enrolments (user_id, module_code) VALUES
  (1, 'CMP-5012B'),
  (1, 'CMP-5013A'),
  (1, 'CMP-5036A');

-- Default semester profile
INSERT INTO semesters (id, user_id, name) VALUES
  (1, 1, 'Spring Semester 2025-2026');

-- Link default semester to all enrolled modules
INSERT INTO semester_modules (semester_id, module_code) VALUES
  (1, 'CMP-5012B'),
  (1, 'CMP-5013A'),
  (1, 'CMP-5036A');

-- Courseworks and exams for each module (scoped to semester 1)
INSERT INTO courseworks (id, semester_id, module_code, name, type, weighting, due_date) VALUES
  (1, 1, 'CMP-5012B', 'Requirements and Design Report', 'coursework', 25, '2026-03-02'),
  (2, 1, 'CMP-5012B', 'Team Demo and Source Code',      'coursework', 30, '2026-06-27'),
  (3, 1, 'CMP-5012B', 'Reflective Report',              'coursework', 15, '2026-05-30'),
  (4, 1, 'CMP-5013A', 'OS Coursework',                  'coursework', 50, '2026-06-16'),
  (5, 1, 'CMP-5036A', 'IR Experiments Report',          'coursework', 55, '2026-06-23');

-- Study tasks (linked to coursework and user)
INSERT INTO tasks (id, user_id, coursework_id, title, start_week, end_week, due_date) VALUES
  (1, 1, 1, 'Gather requirements',     1, 2, '2026-02-10'),
  (2, 1, 1, 'Write design document',   2, 4, '2026-02-24'),
  (3, 1, 2, 'Build backend API',       3, 6, '2026-04-20'),
  (4, 1, 2, 'Build frontend UI',       4, 7, '2026-05-10'),
  (5, 1, 5, 'Implement search engine', 2, 8, '2026-06-10');

-- Milestones for each task
INSERT INTO milestones (id, task_id, name, start_week, end_week, done, deadline) VALUES
  (1, 1, 'Stakeholder interviews done', 1, 1, TRUE,  '2026-02-07'),
  (2, 1, 'Requirements document draft', 1, 2, FALSE, '2026-02-14'),
  (3, 2, 'UML class diagram',           2, 3, TRUE,  '2026-02-17'),
  (4, 2, 'UML sequence diagrams',       3, 4, FALSE, '2026-02-24'),
  (5, 3, 'Database schema done',        3, 4, TRUE,  '2026-04-01'),
  (6, 3, 'API endpoints complete',      4, 6, FALSE, '2026-04-20');

-- Sample activities (hours studied per day for the weekly productivity chart)
INSERT INTO activities (id, user_id, date, time_spent) VALUES
  (1, 1, '2026-05-08', 1.5),
  (2, 1, '2026-05-09', 2.0),
  (3, 1, '2026-05-10', 1.0),
  (4, 1, '2026-05-11', 2.5),
  (5, 1, '2026-05-12', 3.0);

-- Sample timetable entries (dates are in the current week for demo purposes)
INSERT INTO timetable_entries (user_id, entry_date, start_time, end_time, description) VALUES
  (1, CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::INT + 1, '09:00', '10:00', 'CMP-5012B Lecture'),
  (1, CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::INT + 3, '11:00', '12:00', 'CMP-5036A Lab'),
  (1, CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::INT + 4, '14:00', '15:00', 'CMP-5013A Seminar');

-- Sample todos
INSERT INTO todos (user_id, text, done) VALUES
  (1, 'Review lecture slides for this week', FALSE),
  (1, 'Submit requirements document draft',  FALSE),
  (1, 'Book meeting with project supervisor', TRUE);

-- Resync auto-increment sequences after seeding with explicit IDs
SELECT setval(pg_get_serial_sequence('users',       'id'), COALESCE(MAX(id), 0) + 1, false) FROM users;
SELECT setval(pg_get_serial_sequence('semesters',   'id'), COALESCE(MAX(id), 0) + 1, false) FROM semesters;
SELECT setval(pg_get_serial_sequence('courseworks', 'id'), COALESCE(MAX(id), 0) + 1, false) FROM courseworks;
SELECT setval(pg_get_serial_sequence('tasks',       'id'), COALESCE(MAX(id), 0) + 1, false) FROM tasks;
SELECT setval(pg_get_serial_sequence('milestones',  'id'), COALESCE(MAX(id), 0) + 1, false) FROM milestones;
SELECT setval(pg_get_serial_sequence('activities',  'id'), COALESCE(MAX(id), 0) + 1, false) FROM activities;
