// routes/index.js
// Thin router — maps all application URLs to their controllers.
// No business logic or database queries live here.

var express    = require('express');
var router     = express.Router();
var multer     = require('multer');
var requireAuth = require('../middleware/auth');

var homeController      = require('../controllers/homeController');
var dashboardController = require('../controllers/dashboardController');
var plannerController   = require('../controllers/plannerController');
var moduleController    = require('../controllers/moduleController');
var todoController      = require('../controllers/todoController');
var taskController      = require('../controllers/taskController');
var milestoneController = require('../controllers/milestoneController');
var timetableController    = require('../controllers/timetableController');
var uploadController       = require('../controllers/uploadController');
var timetableImportController = require('../controllers/timetableImportController');
var courseworkController   = require('../controllers/courseworkController');
var Module                    = require('../models/Module');

var upload = multer({ storage: multer.memoryStorage() });

// ── Page routes ───────────────────────────────────────────────────────────────

router.get('/',          requireAuth, homeController.index);
router.get('/dashboard', requireAuth, dashboardController.index);
router.get('/planner',   requireAuth, plannerController.index);
router.get('/module',    requireAuth, moduleController.index);

// ── Planner actions ───────────────────────────────────────────────────────────

router.post('/planner/create-profile',
  requireAuth,
  upload.array('courseworkFiles', 10),
  plannerController.createProfile
);

router.post('/planner/switch',          requireAuth, plannerController.switchSemester);
router.post('/planner/delete-profile',  requireAuth, plannerController.deleteProfile);

// ── To-do list ────────────────────────────────────────────────────────────────

router.post('/todos',            requireAuth, todoController.create);
router.post('/todos/:id/toggle', requireAuth, todoController.toggle);
router.post('/todos/:id/delete', requireAuth, todoController.delete);

// ── Legacy file upload ────────────────────────────────────────────────────────

router.post('/upload',
  requireAuth,
  upload.single('semesterFile'),
  uploadController.handleUpload
);

// ── API: modules ──────────────────────────────────────────────────────────────

router.get('/api/modules', requireAuth, async function(req, res) {
  try {
    var modules = await Module.getByUser(req.session.user.id);
    res.json(modules);
  } catch (err) {
    console.error('GET /api/modules error:', err);
    res.status(500).json({ error: 'Could not load modules' });
  }
});

// ── API: tasks ────────────────────────────────────────────────────────────────

router.get('/api/tasks',         requireAuth, taskController.getAll);
router.post('/api/tasks',        requireAuth, taskController.create);
router.put('/api/tasks/:id',     requireAuth, taskController.update);
router.delete('/api/tasks/:id',  requireAuth, taskController.delete);

// ── API: courseworks ──────────────────────────────────────────────────────────

router.get('/api/courseworks/:moduleCode',  requireAuth, courseworkController.getByModule);
router.post('/api/courseworks/parse-pdf',   requireAuth, upload.single('cwFile'), courseworkController.parsePDF);
router.post('/api/courseworks',             requireAuth, courseworkController.create);
router.put('/api/courseworks/:id',          requireAuth, courseworkController.update);
router.delete('/api/courseworks/:id',       requireAuth, courseworkController.delete);

// ── API: milestones ───────────────────────────────────────────────────────────

router.post('/api/milestones',       requireAuth, milestoneController.create);
router.put('/api/milestones/:id',    requireAuth, milestoneController.toggle);
router.delete('/api/milestones/:id', requireAuth, milestoneController.delete);

// ── API: timetable ────────────────────────────────────────────────────────────

router.get('/api/timetable',          requireAuth, timetableController.getWeek);
router.post('/api/timetable',         requireAuth, timetableController.create);
router.delete('/api/timetable/all',   requireAuth, timetableController.clearAll);
router.put('/api/timetable/:id',      requireAuth, timetableController.update);
router.delete('/api/timetable/:id',   requireAuth, timetableController.delete);

router.post('/api/timetable/import',
  requireAuth,
  upload.single('timetableFile'),
  timetableImportController.importPDF
);

module.exports = router;
