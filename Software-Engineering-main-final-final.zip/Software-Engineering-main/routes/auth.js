// routes/auth.js
// Thin router — maps auth URLs to authController.

var express        = require('express');
var router         = express.Router();
var authController = require('../controllers/authController');
var body = require('express-validator').body;
var rateLimit = require('express-rate-limit');

var loginLimiter = rateLimit({
  windowMs: 2 * 60 * 1000,
  max: 3,

  message: 'Too many login attempts. Please try again later.',

  handler: function(req, res) {
    res.render('login', {
      title: 'Login',
      error: 'Too many login attempts. Please try again later.'
    });
  }
});

router.get('/login',  authController.showLogin);

router.post('/login',
  loginLimiter,

  [
    body('username')
      .trim()
      .notEmpty().withMessage('Please enter your username.')
      .isLength({ min: 3, max: 30 }).withMessage('Username must be between 3 and 30 characters.')
      .matches(/^[A-Za-z0-9_]+$/).withMessage('Username can only contain letters, numbers and underscores.'),

    body('password')
      .notEmpty().withMessage('Please enter your password.')
      .isLength({ min: 3, max: 100 }).withMessage('Password must be at least 3 characters.')
  ],

  authController.login
);

router.post('/logout', authController.logout);

module.exports = router;