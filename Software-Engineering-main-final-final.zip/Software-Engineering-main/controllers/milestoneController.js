// controllers/milestoneController.js
// Handles the /api/milestones REST endpoints consumed by dashboard.js.

var Milestone = require('../models/Milestone');

exports.create = async function(req, res) {
  var userId = req.session.user.id;
  try {
    var owned = await Milestone.verifyTaskOwnership(req.body.taskId, userId);
    if (!owned) {
      return res.status(403).json({ error: 'Not allowed' });
    }
    var milestone = await Milestone.create(
      req.body.taskId,
      req.body.name,
      parseInt(req.body.startWeek) || 1,
      parseInt(req.body.endWeek)   || 1
    );
    res.json(milestone);
  } catch (err) {
    console.error('POST /api/milestones error:', err);
    res.status(500).json({ error: 'Could not add milestone' });
  }
};

exports.toggle = async function(req, res) {
  try {
    await Milestone.toggle(req.params.id, req.session.user.id);
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/milestones/:id error:', err);
    res.status(500).json({ error: 'Could not update milestone' });
  }
};

exports.delete = async function(req, res) {
  try {
    await Milestone.delete(req.params.id, req.session.user.id);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/milestones/:id error:', err);
    res.status(500).json({ error: 'Could not delete milestone' });
  }
};
