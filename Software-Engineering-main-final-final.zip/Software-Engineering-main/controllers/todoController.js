// controllers/todoController.js
// Handles to-do list CRUD — all actions redirect back to the home page.

var Todo = require('../models/Todo');

exports.create = async function(req, res) {
  var text = (req.body.text || '').trim();
  if (text) {
    try {
      await Todo.create(req.session.user.id, text);
    } catch (err) {
      console.error('Add todo error:', err);
    }
  }
  res.redirect('/');
};

exports.toggle = async function(req, res) {
  try {
    await Todo.toggle(req.params.id, req.session.user.id);
  } catch (err) {
    console.error('Toggle todo error:', err);
  }
  res.redirect('/');
};

exports.delete = async function(req, res) {
  try {
    await Todo.delete(req.params.id, req.session.user.id);
  } catch (err) {
    console.error('Delete todo error:', err);
  }
  res.redirect('/');
};
