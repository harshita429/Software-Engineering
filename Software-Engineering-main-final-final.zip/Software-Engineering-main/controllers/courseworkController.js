var pdfParse           = require('pdf-parse');
var Coursework         = require('../models/Coursework');
var Semester           = require('../models/Semester');
var Module             = require('../models/Module');
var parseCourseworkPDF = require('../utils/parseCwPDF');

exports.create = async function(req, res) {
  try {
    var { semesterId, moduleCode, name, type, weighting, dueDate } = req.body;
    if (!semesterId || !moduleCode || !name || !dueDate) {
      return res.status(400).json({ error: 'Semester, module, name and due date are required.' });
    }
    var cw = await Coursework.create(semesterId, moduleCode, name, type || 'coursework', weighting || null, dueDate);
    res.json(cw);
  } catch (err) {
    console.error('POST /api/courseworks error:', err);
    res.status(500).json({ error: 'Could not create coursework.' });
  }
};

exports.update = async function(req, res) {
  try {
    var id = parseInt(req.params.id);
    var { name, type, weighting, dueDate } = req.body;
    if (!name || !dueDate) {
      return res.status(400).json({ error: 'Name and due date are required.' });
    }
    await Coursework.update(id, name, type || 'coursework', weighting || null, dueDate);
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/courseworks/:id error:', err);
    res.status(500).json({ error: 'Could not update coursework.' });
  }
};

exports.delete = async function(req, res) {
  try {
    var id = parseInt(req.params.id);
    await Coursework.delete(id);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/courseworks/:id error:', err);
    res.status(500).json({ error: 'Could not delete coursework.' });
  }
};

exports.parsePDF = async function(req, res) {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded.' });
    var pdfData = await pdfParse(req.file.buffer);
    var parsed  = parseCourseworkPDF(pdfData.text);
    res.json(parsed);
  } catch (err) {
    console.error('POST /api/courseworks/parse-pdf error:', err);
    res.status(500).json({ error: 'Could not parse PDF.' });
  }
};

exports.getByModule = async function(req, res) {
  try {
    var cws = await Coursework.getByModule(req.params.moduleCode);
    res.json(cws);
  } catch (err) {
    console.error('GET /api/courseworks/:moduleCode error:', err);
    res.status(500).json({ error: 'Could not load courseworks.' });
  }
};
