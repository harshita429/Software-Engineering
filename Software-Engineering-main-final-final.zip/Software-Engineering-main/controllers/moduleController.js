// controllers/moduleController.js
// Handles the module page: Gantt chart, milestones, and coursework deadlines.

var Module     = require('../models/Module');
var Task       = require('../models/Task');
var Milestone  = require('../models/Milestone');
var Coursework = require('../models/Coursework');

exports.index = async function(req, res) {
  var userId         = req.session.user.id;
  var selectedModule = req.query.module || '';

  try {
    var allModules  = await Module.getByUser(userId);
    var tasks       = [];
    var milestones  = [];
    var courseworks = [];

    if (selectedModule) {
      tasks = await Task.getByModule(userId, selectedModule);

      if (tasks.length > 0) {
        var taskIds = tasks.map(function(t) { return t.id; });
        milestones  = await Milestone.getByTasks(taskIds);
      }

      courseworks = await Coursework.getByModule(selectedModule);
    }

    res.render('module', {
      title:          'Module Page',
      user:           req.session.user,
      selectedModule: selectedModule,
      allModules:     allModules,
      tasks:          tasks,
      milestones:     milestones,
      courseworks:    courseworks
    });

  } catch (err) {
    console.error('Module page error:', err);
    res.render('module', {
      title:          'Module Page',
      user:           req.session.user,
      selectedModule: selectedModule,
      allModules:     [],
      tasks:          [],
      milestones:     [],
      courseworks:    []
    });
  }
};
