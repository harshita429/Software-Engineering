// controllers/dashboardController.js
// Serves the dashboard shell — task data is loaded client-side via the API.

exports.index = function(req, res) {
  res.render('dashboard', {
    title: 'Study Dashboard',
    user:  req.session.user
  });
};
