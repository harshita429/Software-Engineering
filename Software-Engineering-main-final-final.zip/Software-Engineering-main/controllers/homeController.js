// controllers/homeController.js
// Handles the home page — assembles modules, deadlines, todos, and weekly hours.

var Module   = require('../models/Module');
var Task     = require('../models/Task');
var Todo     = require('../models/Todo');

exports.index = async function(req, res) {
  var userId = req.session.user.id;

  try {
    var modules      = await Module.getByUser(userId);
    var rawDeadlines = await Task.getUpcomingDeadlines(userId);
    var todos        = await Todo.getByUser(userId);

    // Attach days-left count and urgency colour to each deadline
    var today = new Date();
    today.setHours(0, 0, 0, 0);

    var deadlines = rawDeadlines.map(function(d) {
      var due = new Date(d.due_date);
      due.setHours(0, 0, 0, 0);
      var daysLeft = Math.round((due - today) / 86400000);
      d.daysLeft = daysLeft;
      d.urgency  = daysLeft < 7 ? 'red' : daysLeft < 14 ? 'yellow' : 'green';
      return d;
    });

    res.render('home', {
      title:     'Study Planner',
      user:      req.session.user,
      modules:   modules,
      deadlines: deadlines,
      todos:     todos,
      today:     new Date().toLocaleDateString('en-GB')
    });

  } catch (err) {
    console.error('Home page error:', err);
    res.render('home', {
      title:     'Study Planner',
      user:      req.session.user,
      modules:   [],
      deadlines: [],
      todos:     [],
      today:     new Date().toLocaleDateString('en-GB')
    });
  }
};
