// controllers/timetableController.js
// Handles the /api/timetable REST endpoints consumed by planner.js.

var Timetable = require('../models/Timetable');

exports.getWeek = async function(req, res) {
  if (!req.query.weekStart) {
    return res.status(400).json({ error: 'weekStart required' });
  }
  try {
    var entries = await Timetable.getWeek(req.session.user.id, req.query.weekStart);
    res.json(entries);
  } catch (err) {
    console.error('GET /api/timetable error:', err);
    res.status(500).json({ error: 'Could not load timetable' });
  }
};

exports.create = async function(req, res) {
  try {
    var entry = await Timetable.create(
      req.session.user.id,
      req.body.entryDate,
      req.body.startTime,
      req.body.endTime,
      req.body.description || ''
    );
    res.json(entry);
  } catch (err) {
    console.error('POST /api/timetable error:', err);
    res.status(500).json({ error: 'Could not save timetable entry' });
  }
};

exports.update = async function(req, res) {
  try {
    await Timetable.update(
      req.params.id,
      req.session.user.id,
      req.body.entryDate,
      req.body.startTime,
      req.body.endTime,
      req.body.description || ''
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/timetable/:id error:', err);
    res.status(500).json({ error: 'Could not update timetable entry' });
  }
};

exports.delete = async function(req, res) {
  try {
    await Timetable.delete(req.params.id, req.session.user.id);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/timetable/:id error:', err);
    res.status(500).json({ error: 'Could not delete timetable entry' });
  }
};

exports.clearAll = async function(req, res) {
  try {
    await Timetable.clearAll(req.session.user.id);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/timetable/all error:', err);
    res.status(500).json({ error: 'Could not clear timetable entries' });
  }
};
