var pdfParse = require('pdf-parse');
var Timetable = require('../models/Timetable');

var MONTHS = {
  January: '01', February: '02', March: '03', April: '04',
  May: '05', June: '06', July: '07', August: '08',
  September: '09', October: '10', November: '11', December: '12'
};

function cleanTitle(title) {
  title = title.replace(/\s+/g, ' ').trim();

  // remove the final Type column text
  title = title.replace(/\s+(Lecture|IT\s*Laboratory|Seminar|Workshop|Induction|Other)$/i, '').trim();

  return title;
}

function parseTimetablePDF(text) {
  var entries = [];
  var seen = new Set();

  var flat = text
    .replace(/\r/g, ' ')
    .replace(/\n/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/(\d{2}:\d{2})(\d{2}:\d{2})/g, '$1 $2')
    .replace(/(Lecture)(Lecture)/g, '$1 $2')
    .replace(/(Laboratory)(Mon|Tue|Wed|Thu|Fri|Sat|Sun)/g, '$1 $2')
    .replace(/(Lecture)(Mon|Tue|Wed|Thu|Fri|Sat|Sun)/g, '$1 $2')
    .replace(/(\d{4})(\d{2}:\d{2})/g, '$1 $2')
    .trim();

  console.log('PDF TEXT SAMPLE:', flat.substring(0, 1500));

  var regex = /(CMP-\d{4}[A-Z]?\s+.*?)(Mon|Tue|Wed|Thu|Fri|Sat|Sun),?\s+(\d{1,2})(?:st|nd|rd|th)?\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})\s+(\d{2}:\d{2})\s+(\d{2}:\d{2})/g;

  var match;

  while ((match = regex.exec(flat)) !== null) {
    var rawTitle = match[1];

    rawTitle = rawTitle
      .replace(/Lecture\s+Lecture/gi, 'Lecture')
      .replace(/IT\s+Laboratory/gi, 'IT Laboratory')
      .replace(/\s+/g, ' ')
      .trim();

    var day = match[3].padStart(2, '0');
    var month = MONTHS[match[4]];
    var year = match[5];

    var entry = {
      description: rawTitle,
      entryDate: year + '-' + month + '-' + day,
      startTime: match[6],
      endTime: match[7]
    };

    var key = entry.description + '|' + entry.entryDate + '|' + entry.startTime + '|' + entry.endTime;

    if (!seen.has(key)) {
      seen.add(key);
      entries.push(entry);
    }
  }

  return entries;
}

exports.importPDF = async function(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No timetable PDF uploaded.' });
    }

    var pdfData = await pdfParse(req.file.buffer);
    var entries = parseTimetablePDF(pdfData.text);

    console.log('Parsed entries:', entries);

    if (entries.length === 0) {
      return res.status(400).json({
        error: 'The PDF uploaded, but no CMP timetable rows were found.'
      });
    }

    var userId = req.session.user.id;
    var count = 0;

    for (var i = 0; i < entries.length; i++) {
      var e = entries[i];

      await Timetable.create(
        userId,
        e.entryDate,
        e.startTime,
        e.endTime,
        e.description
      );

      count++;
    }

    var firstDate = entries.reduce(function(min, e) {
      return e.entryDate < min ? e.entryDate : min;
    }, entries[0].entryDate);

    res.json({
      imported:  count,
      firstDate: firstDate,
      message:   count + ' timetable entr' + (count === 1 ? 'y' : 'ies') + ' imported.'
    });

  } catch (err) {
    console.error('Timetable import error:', err);
    res.status(500).json({ error: 'Could not import timetable PDF.' });
  }
};