// controllers/authController.js
// Handles login and logout logic.

var User = require('../models/User');
var validationResult = require('express-validator').validationResult;

exports.showLogin = function(req, res) {
  if (req.session.user) {
    return res.redirect('/');
  }
  res.render('login', { title: 'Login', error: null });
};

exports.login = async function(req, res) {
    var errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.render('login', {
      title: 'Login',
      error: errors.array()[0].msg
    });
  }
  var username = req.body.username;
  var password = req.body.password;

  if (!username || !password) {
    return res.render('login', {
      title: 'Login',
      error: 'Please enter your username and password.'
    });
  }

  try {
    var user = await User.findByUsername(username);

    if (!user) {
      return res.render('login', {
        title: 'Login',
        error: 'Username or password is incorrect.'
      });
    }

    var passwordMatches = await User.verifyPassword(password, user.password_hash);
    if (!passwordMatches) {
      return res.render('login', {
        title: 'Login',
        error: 'Username or password is incorrect.'
      });
    }

    req.session.user = {
      id:       user.id,
      name:     user.name,
      username: user.username
    };
    res.redirect('/');

  } catch (err) {
    console.error('Login error:', err);
    res.render('login', {
      title: 'Login',
      error: 'Something went wrong. Please try again.'
    });
  }
};

exports.logout = function(req, res) {
  req.session.destroy(function() {
    res.redirect('/login');
  });
};
