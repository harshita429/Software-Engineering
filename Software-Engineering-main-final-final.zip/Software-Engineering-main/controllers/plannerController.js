// controllers/plannerController.js
// Handles the planner page: semester profiles and the weekly timetable shell.

var pdfParse          = require('pdf-parse');
var Semester          = require('../models/Semester');
var Module            = require('../models/Module');
var Coursework        = require('../models/Coursework');
var parseCourseworkPDF = require('../utils/parseCwPDF');

exports.index = async function(req, res) {
  var userId     = req.session.user.id;
  var flashError = req.session.plannerError || null;
  req.session.plannerError = null;

  try {
    var semesters        = await Semester.getByUser(userId);
    var activeSemesterId = req.session.activeSemesterId || null;
    var activeSemester   = null;

    if (semesters.length > 0) {
      if (activeSemesterId) {
        activeSemester = semesters.find(function(s) { return s.id === activeSemesterId; }) || semesters[0];
      } else {
        activeSemester = semesters[0];
      }
      req.session.activeSemesterId = activeSemester.id;
    }

    var semesterModules = [];
    if (activeSemester) {
      var mods = await Semester.getModules(activeSemester.id);
      for (var i = 0; i < mods.length; i++) {
        var cws = await Coursework.getByModule(mods[i].code, activeSemester.id);
        semesterModules.push({ module: mods[i], courseworks: cws });
      }
    }

    res.render('planner', {
      title:           'Study Planner',
      user:            req.session.user,
      semesters:       semesters,
      activeSemester:  activeSemester,
      semesterModules: semesterModules,
      flashError:      flashError
    });

  } catch (err) {
    console.error('Planner page error:', err);
    res.render('planner', {
      title:           'Study Planner',
      user:            req.session.user,
      semesters:       [],
      activeSemester:  null,
      semesterModules: [],
      flashError:      flashError
    });
  }
};

exports.createProfile = async function(req, res) {
  var userId      = req.session.user.id;
  var profileName = (req.body.profileName || '').trim();

  if (!profileName) {
    req.session.plannerError = 'Please enter a profile name.';
    return res.redirect('/planner');
  }
  if (!req.files || req.files.length === 0) {
    req.session.plannerError = 'Please upload at least one coursework PDF.';
    return res.redirect('/planner');
  }

  try {
    var semesterId = await Semester.create(userId, profileName);
    var totalItems = 0;

    for (var f = 0; f < req.files.length; f++) {
      var file = req.files[f];

      // Extract module code from filename (e.g. CMP-5012B-assignment.pdf → CMP-5012B)
      var codeMatch  = file.originalname.match(/([A-Z]+-\d+[A-Z]*)/i);
      var moduleCode = codeMatch ? codeMatch[1].toUpperCase() : null;

      if (!moduleCode) {
        console.warn('Could not extract module code from filename:', file.originalname);
        continue;
      }

      var pdfData  = await pdfParse(file.buffer);
      var parsed   = parseCourseworkPDF(pdfData.text);
      var modName  = parsed.moduleName || moduleCode;

      await Module.upsert(moduleCode, modName);
      await Module.enrol(userId, moduleCode);
      await Semester.addModule(semesterId, moduleCode);

      for (var i = 0; i < parsed.items.length; i++) {
        var item = parsed.items[i];
        await Coursework.create(semesterId, moduleCode, item.name, 'coursework', item.weighting, item.dueDate);
        totalItems++;
      }

      // If no dateable items were found, still keep the module in the semester
      if (parsed.items.length === 0) {
        console.warn('No coursework items parsed from:', file.originalname);
      }
    }

    req.session.activeSemesterId = semesterId;
    console.log('Created profile "' + profileName + '" with ' + totalItems + ' coursework item(s).');
    res.redirect('/planner');

  } catch (err) {
    console.error('Create profile error:', err);
    req.session.plannerError = 'Something went wrong saving the profile. Please try again.';
    res.redirect('/planner');
  }
};

exports.deleteProfile = async function(req, res) {
  var userId     = req.session.user.id;
  var semesterId = parseInt(req.body.semesterId);

  try {
    var owned = await Semester.verifyOwnership(semesterId, userId);
    if (owned) {
      await Semester.delete(semesterId, userId);
      if (req.session.activeSemesterId === semesterId) {
        req.session.activeSemesterId = null;
      }
    }
  } catch (err) {
    console.error('Delete profile error:', err);
  }
  res.redirect('/planner');
};

exports.switchSemester = async function(req, res) {
  var userId     = req.session.user.id;
  var semesterId = parseInt(req.body.semesterId);

  try {
    var owned = await Semester.verifyOwnership(semesterId, userId);
    if (owned) {
      req.session.activeSemesterId = semesterId;
    }
  } catch (err) {
    console.error('Switch semester error:', err);
  }
  res.redirect('/planner');
};
