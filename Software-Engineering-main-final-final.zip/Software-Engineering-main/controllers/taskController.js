// controllers/taskController.js
// Handles the /api/tasks REST endpoints consumed by dashboard.js.

var Task = require('../models/Task');

exports.getAll = async function(req, res) {
  try {
    var tasks = await Task.getByUser(req.session.user.id);
    res.json(tasks);
  } catch (err) {
    console.error('GET /api/tasks error:', err);
    res.status(500).json({ error: 'Could not load tasks' });
  }
};

exports.create = async function(req, res) {
  try {
    var task = await Task.create(
      req.session.user.id,
      req.body.title || 'New Task',
      req.body.dueDate || null
    );
    task.milestones = [];
    res.json(task);
  } catch (err) {
    console.error('POST /api/tasks error:', err);
    res.status(500).json({ error: 'Could not create task' });
  }
};

exports.update = async function(req, res) {
  try {
    await Task.update(
      req.params.id,
      req.session.user.id,
      req.body.title,
      req.body.dueDate    || null,
      req.body.moduleCode || null
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('PUT /api/tasks/:id error:', err);
    res.status(500).json({ error: 'Could not update task' });
  }
};

exports.delete = async function(req, res) {
  try {
    await Task.delete(req.params.id, req.session.user.id);
    res.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/tasks/:id error:', err);
    res.status(500).json({ error: 'Could not delete task' });
  }
};
