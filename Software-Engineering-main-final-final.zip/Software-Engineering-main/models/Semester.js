// models/Semester.js
// Handles all database operations for the semesters and semester_modules tables.

var db = require('../db');

module.exports = {
  getByUser: async function(userId) {
    var result = await db.query(
      'SELECT s.id, s.name, s.created_at ' +
      'FROM semesters s ' +
      'WHERE s.user_id = $1 ' +
      'ORDER BY s.created_at DESC',
      [userId]
    );
    return result.rows;
  },

  create: async function(userId, name) {
    var result = await db.query(
      'INSERT INTO semesters (user_id, name) VALUES ($1, $2) RETURNING id',
      [userId, name]
    );
    return result.rows[0].id;
  },

  // Modules linked to a semester, with their coursework count.
  getModules: async function(semesterId) {
    var result = await db.query(
      'SELECT m.code, m.name, ' +
      '(SELECT COUNT(*) FROM courseworks c WHERE c.module_code = m.code) as coursework_count ' +
      'FROM modules m ' +
      'JOIN semester_modules sm ON m.code = sm.module_code ' +
      'WHERE sm.semester_id = $1 ' +
      'ORDER BY m.code',
      [semesterId]
    );
    return result.rows;
  },

  // Link a module to a semester, ignoring duplicates.
  addModule: async function(semesterId, moduleCode) {
    await db.query(
      'INSERT INTO semester_modules (semester_id, module_code) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [semesterId, moduleCode]
    );
  },

  // Confirm that a semester belongs to the user before switching to it.
  verifyOwnership: async function(semesterId, userId) {
    var result = await db.query(
      'SELECT id FROM semesters WHERE id = $1 AND user_id = $2',
      [semesterId, userId]
    );
    return result.rows.length > 0;
  },

  delete: async function(semesterId, userId) {
    await db.query(
      'DELETE FROM semesters WHERE id = $1 AND user_id = $2',
      [semesterId, userId]
    );
  }
};
