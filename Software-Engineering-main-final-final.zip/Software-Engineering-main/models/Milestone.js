// models/Milestone.js
// Handles all database operations for the milestones table.

var db = require('../db');

module.exports = {
  // Fetch milestones for a set of task IDs, with the parent task title joined in.
  getByTasks: async function(taskIds) {
    var placeholders = taskIds.map(function(_, i) { return '$' + (i + 1); }).join(', ');
    var result = await db.query(
      'SELECT mil.*, t.title as task_title ' +
      'FROM milestones mil ' +
      'JOIN tasks t ON mil.task_id = t.id ' +
      'WHERE mil.task_id IN (' + placeholders + ') ' +
      'ORDER BY mil.deadline ASC NULLS LAST',
      taskIds
    );
    return result.rows;
  },

  // Confirm that a task belongs to the user before allowing milestone creation.
  verifyTaskOwnership: async function(taskId, userId) {
    var result = await db.query(
      'SELECT id FROM tasks WHERE id = $1 AND user_id = $2',
      [taskId, userId]
    );
    return result.rows.length > 0;
  },

  create: async function(taskId, name, startWeek, endWeek) {
    var result = await db.query(
      'INSERT INTO milestones (task_id, name, start_week, end_week) VALUES ($1, $2, $3, $4) RETURNING *',
      [taskId, name, startWeek, endWeek]
    );
    return result.rows[0];
  },

  // Toggles the done flag — ownership is verified via the tasks sub-query.
  toggle: async function(milestoneId, userId) {
    await db.query(
      'UPDATE milestones SET done = NOT done ' +
      'WHERE id = $1 AND task_id IN (SELECT id FROM tasks WHERE user_id = $2)',
      [milestoneId, userId]
    );
  },

  delete: async function(milestoneId, userId) {
    await db.query(
      'DELETE FROM milestones ' +
      'WHERE id = $1 AND task_id IN (SELECT id FROM tasks WHERE user_id = $2)',
      [milestoneId, userId]
    );
  }
};
