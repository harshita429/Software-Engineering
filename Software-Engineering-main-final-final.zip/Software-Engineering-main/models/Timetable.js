// models/Timetable.js
// Handles all database operations for the timetable_entries table.

var db = require('../db');

module.exports = {
  // Returns all entries for a given user within the 7-day window starting on weekStart.
  getWeek: async function(userId, weekStart) {
    var result = await db.query(
      'SELECT id, user_id, ' +
      "TO_CHAR(entry_date, 'YYYY-MM-DD') AS entry_date, " +
      'start_time, end_time, description ' +
      'FROM timetable_entries ' +
      'WHERE user_id = $1 AND entry_date >= $2 AND entry_date <= ($2::date + 6) ' +
      'ORDER BY entry_date, start_time',
      [userId, weekStart]
    );
    return result.rows;
  },

  create: async function(userId, entryDate, startTime, endTime, description) {
    var result = await db.query(
      'INSERT INTO timetable_entries (user_id, entry_date, start_time, end_time, description) ' +
      "VALUES ($1, $2, $3, $4, $5) " +
      "RETURNING id, user_id, TO_CHAR(entry_date, 'YYYY-MM-DD') AS entry_date, start_time, end_time, description",
      [userId, entryDate, startTime, endTime, description]
    );
    return result.rows[0];
  },

  update: async function(entryId, userId, entryDate, startTime, endTime, description) {
    await db.query(
      'UPDATE timetable_entries ' +
      'SET entry_date = $1, start_time = $2, end_time = $3, description = $4 ' +
      'WHERE id = $5 AND user_id = $6',
      [entryDate, startTime, endTime, description, entryId, userId]
    );
  },

  delete: async function(entryId, userId) {
    await db.query(
      'DELETE FROM timetable_entries WHERE id = $1 AND user_id = $2',
      [entryId, userId]
    );
  },

  findByDateRange: async function(userId, startDate, endDate) {
  var result = await db.query(
    `SELECT id, user_id, TO_CHAR(entry_date, 'YYYY-MM-DD') AS entry_date, start_time, end_time, description
     FROM timetable_entries
     WHERE user_id = $1
     AND entry_date BETWEEN $2 AND $3
     ORDER BY entry_date, start_time`,
    [userId, startDate, endDate]
    );
    return result.rows;
  },

  findDuplicate: async function(userId, entryDate, startTime, endTime, description) {
  var result = await db.query(
    `SELECT id FROM timetable_entries
     WHERE user_id = $1
     AND entry_date = $2
     AND start_time = $3
     AND end_time = $4
     AND description = $5
     LIMIT 1`,
    [userId, entryDate, startTime, endTime, description]
    );
    return result.rows[0];
  },

  clearAll: async function(userId) {
    await db.query(
      'DELETE FROM timetable_entries WHERE user_id = $1',
      [userId]
    );
  }
};
