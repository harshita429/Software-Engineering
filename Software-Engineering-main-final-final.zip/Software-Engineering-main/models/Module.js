// models/Module.js
// Handles all database operations for the modules and enrolments tables.

var db = require('../db');

module.exports = {
  // All modules a student is enrolled in, ordered by code.
  getByUser: async function(userId) {
    var result = await db.query(
      'SELECT m.code, m.name ' +
      'FROM modules m ' +
      'JOIN enrolments e ON m.code = e.module_code ' +
      'WHERE e.user_id = $1 ' +
      'ORDER BY m.code',
      [userId]
    );
    return result.rows;
  },

  // Insert a module if it doesn't already exist (code is the primary key).
  upsert: async function(code, name) {
    await db.query(
      'INSERT INTO modules (code, name) VALUES ($1, $2) ON CONFLICT (code) DO NOTHING',
      [code, name]
    );
  },

  // Enrol a user in a module, ignoring duplicates.
  enrol: async function(userId, moduleCode) {
    await db.query(
      'INSERT INTO enrolments (user_id, module_code) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [userId, moduleCode]
    );
  }
};
