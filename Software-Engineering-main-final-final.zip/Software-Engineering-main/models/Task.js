// models/Task.js
// Handles all database operations for the tasks table.

var db = require('../db');

module.exports = {
  // Fetch all tasks for a user, with milestones attached and module code resolved.
  getByUser: async function(userId) {
    var tasksResult = await db.query(
      'SELECT t.*, c.name as coursework_name, ' +
      'COALESCE(t.module_code, c.module_code) as module_code ' +
      'FROM tasks t ' +
      'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
      'WHERE t.user_id = $1 ' +
      'ORDER BY t.created_at ASC',
      [userId]
    );
    var tasks = tasksResult.rows;

    var milResult = await db.query(
      'SELECT * FROM milestones ' +
      'WHERE task_id IN (SELECT id FROM tasks WHERE user_id = $1) ' +
      'ORDER BY start_week ASC',
      [userId]
    );

    tasks.forEach(function(task) {
      task.milestones = milResult.rows.filter(function(m) {
        return m.task_id === task.id;
      });
    });

    return tasks;
  },

  // Fetch tasks belonging to a specific module (via coursework join or direct module_code).
  getByModule: async function(userId, moduleCode) {
    var result = await db.query(
      'SELECT t.*, c.name as coursework_name ' +
      'FROM tasks t ' +
      'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
      'WHERE t.user_id = $1 AND (c.module_code = $2 OR t.module_code = $2) ' +
      'ORDER BY COALESCE(t.start_week, 99) ASC',
      [userId, moduleCode]
    );
    return result.rows;
  },

  // Fetch future-dated tasks for the home page deadline list.
  getUpcomingDeadlines: async function(userId) {
    var result = await db.query(
      'SELECT t.id, t.title as name, t.due_date, ' +
      'COALESCE(t.module_code, c.module_code) as module_code ' +
      'FROM tasks t ' +
      'LEFT JOIN courseworks c ON t.coursework_id = c.id ' +
      'WHERE t.user_id = $1 AND t.due_date IS NOT NULL AND t.due_date >= CURRENT_DATE ' +
      'ORDER BY t.due_date ASC',
      [userId]
    );
    return result.rows;
  },

  create: async function(userId, title, dueDate) {
    var result = await db.query(
      'INSERT INTO tasks (user_id, title, due_date) VALUES ($1, $2, $3) RETURNING *',
      [userId, title, dueDate]
    );
    return result.rows[0];
  },

  update: async function(taskId, userId, title, dueDate, moduleCode) {
    await db.query(
      'UPDATE tasks SET title = $1, due_date = $2, module_code = $3 ' +
      'WHERE id = $4 AND user_id = $5',
      [title, dueDate, moduleCode, taskId, userId]
    );
  },

  delete: async function(taskId, userId) {
    await db.query(
      'DELETE FROM tasks WHERE id = $1 AND user_id = $2',
      [taskId, userId]
    );
  }
};
