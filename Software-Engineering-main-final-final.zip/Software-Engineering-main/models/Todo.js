// models/Todo.js
// Handles all database operations for the todos table.

var db = require('../db');

module.exports = {
  getByUser: async function(userId) {
    var result = await db.query(
      'SELECT * FROM todos WHERE user_id = $1 ORDER BY id ASC',
      [userId]
    );
    return result.rows;
  },

  create: async function(userId, text) {
    await db.query(
      'INSERT INTO todos (user_id, text) VALUES ($1, $2)',
      [userId, text]
    );
  },

  toggle: async function(todoId, userId) {
    await db.query(
      'UPDATE todos SET done = NOT done WHERE id = $1 AND user_id = $2',
      [todoId, userId]
    );
  },

  delete: async function(todoId, userId) {
    await db.query(
      'DELETE FROM todos WHERE id = $1 AND user_id = $2',
      [todoId, userId]
    );
  }
};
