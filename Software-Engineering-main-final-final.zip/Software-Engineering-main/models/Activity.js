// models/Activity.js
// Handles all database operations for the activities table.

var db = require('../db');

module.exports = {
  // Returns a 7-element array [Mon, Tue, Wed, Thu, Fri, Sat, Sun] of hours studied
  // for the current ISO week (Monday-based).
  getWeeklyHours: async function(userId) {
    var result = await db.query(
      "SELECT EXTRACT(ISODOW FROM date) AS dow, COALESCE(SUM(time_spent), 0) AS hours " +
      "FROM activities " +
      "WHERE user_id = $1 " +
      "AND date >= date_trunc('week', CURRENT_DATE) " +
      "AND date < date_trunc('week', CURRENT_DATE) + INTERVAL '7 days' " +
      "GROUP BY dow ORDER BY dow",
      [userId]
    );

    var weeklyHours = [0, 0, 0, 0, 0, 0, 0];
    result.rows.forEach(function(r) {
      var idx = parseInt(r.dow) - 1; // ISODOW: Mon=1 → index 0
      if (idx >= 0 && idx < 7) {
        weeklyHours[idx] = parseFloat(r.hours);
      }
    });
    return weeklyHours;
  }
};
