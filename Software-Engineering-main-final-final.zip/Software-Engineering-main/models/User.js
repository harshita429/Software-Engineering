// models/User.js
// Handles all database operations for the users table.

var db     = require('../db');
var bcrypt = require('bcryptjs');

module.exports = {
  findByUsername: async function(username) {
    var result = await db.query(
      'SELECT * FROM users WHERE username = $1',
      [username]
    );
    return result.rows[0] || null;
  },

  verifyPassword: async function(plaintext, hash) {
    return bcrypt.compare(plaintext, hash);
  }
};
