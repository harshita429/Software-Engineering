// middleware/auth.js
// Redirects unauthenticated requests to /login.
// Applied to every route that requires a logged-in user.

function requireAuth(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
}

module.exports = requireAuth;
