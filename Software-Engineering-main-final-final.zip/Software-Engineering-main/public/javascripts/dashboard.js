// Loads tasks from the server via fetch() and handles all task/milestone CRUD.

var selectedTaskId = null;
// list of all tasks fetched from the server 
var tasks = [];

var upcomingTasks    = document.getElementById('upcomingTasks');
var inProgressTasks  = document.getElementById('inProgressTasks');
var completedTasks   = document.getElementById('completedTasks');
var taskPopup        = document.getElementById('taskPopup');
var taskTitleInput   = document.getElementById('taskTitleInput');
var moduleSelect     = document.getElementById('moduleSelect');
var taskDueDate      = document.getElementById('taskDueDate');
var ganttRows        = document.getElementById('ganttRows');
var milestoneForm    = document.getElementById('milestoneForm');
var addTaskButton    = document.getElementById('addTaskButton');
var saveTaskButton   = document.getElementById('saveTaskButton');
var deleteTaskButton = document.getElementById('deleteTaskButton');

// Fetch list of modules user is enrolled in to populate the module dropdown in the task popup
document.addEventListener('DOMContentLoaded', function() {
  fetch('/api/modules')
    .then(function(res) { return res.json(); })
    .then(function(modules) {
      modules.forEach(function(m) {
        var opt = document.createElement('option');
        opt.value       = m.code;
        opt.textContent = m.code + ' — ' + m.name;
        moduleSelect.appendChild(opt);
      });
      loadTasks(); // load tasks only after modules are in the dropdown
    })
    .catch(function(err) {
      console.error('Load modules error:', err);
      loadTasks(); // still load tasks even if modules fail
    });
});

// Fetch tasks from server and display them in the correct columns
function loadTasks() {
  fetch('/api/tasks')
    .then(function(res) { return res.json(); })
    .then(function(data) {
      tasks = data;
      displayTasks();
      // If URL has ?open=ID, auto-open that task popup
      var match = window.location.search.match(/open=(\d+)/);
      if (match) {
        openTaskPopup(parseInt(match[1]));
      }
    })
    .catch(function(err) { console.error('Could not load tasks:', err); });
}

function closePopup() {
  taskPopup.classList.add('hidden');
  selectedTaskId = null;
}

// Click outside the popup to close
taskPopup.addEventListener('click', function(e) {
  if (e.target === taskPopup) {
    closePopup();
  }
});

// Add new task with blank values
addTaskButton.addEventListener('click', function() {
  fetch('/api/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title: 'New Task', dueDate: null })
  })
    .then(function(res) { return res.json(); })
    .then(function(task) {
      tasks.push(task);
      displayTasks();
      openTaskPopup(task.id); // open the new task's popup immediately
    })
    .catch(function(err) { console.error('Create task error:', err); });
});

// Save changes to task title, module, and due date
saveTaskButton.addEventListener('click', function() {
  var task = findSelectedTask();
  if (!task) return;

  var trimmedTitle = taskTitleInput.value.trim();
  if (!trimmedTitle) { alert('Please enter a task name.'); return; }

  task.title       = trimmedTitle;
  task.module_code = moduleSelect.value || null;
  task.due_date    = taskDueDate.value  || null;

  // Updates the task on the server with the updated title, due date and module.
  fetch('/api/tasks/' + task.id, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      title:      trimmedTitle,
      dueDate:    task.due_date,
      moduleCode: task.module_code
    })
  })
    .then(function() {
      displayTasks();
      closePopup(); // close after saving
    })
    .catch(function(err) { console.error('Save task error:', err); });
});

// Local live update of the task title as the user types it in
taskTitleInput.addEventListener('input', function() {
  var task = findSelectedTask();
  if (!task) return;
  task.title = taskTitleInput.value;
  displayTasks();
});

// Deletes task from the database then the local tasks list then updates display
deleteTaskButton.addEventListener('click', function() {
  var task = findSelectedTask();
  if (!task) return;
  fetch('/api/tasks/' + task.id, { method: 'DELETE' })
    .then(function() {
      tasks = tasks.filter(function(t) { return t.id !== task.id; });
      closePopup();
      displayTasks();
    })
    .catch(function(err) { console.error('Delete task error:', err); });
});

// Adds a new milestone to the selected task, 
milestoneForm.addEventListener('submit', function(event) {
  event.preventDefault();
  var task = findSelectedTask();
  if (!task) return;

  var name      = document.getElementById('milestoneName').value.trim();
  var startWeek = parseInt(document.getElementById('startWeek').value);
  var endWeek   = parseInt(document.getElementById('endWeek').value);

  if (!name) { alert('Please enter a milestone name.'); return; }
  if (endWeek < startWeek) { alert('End week must be the same as or after start week.'); return; }

  // Creates a milestone on the server, then adds it to the task's milestones list and updates the display
  fetch('/api/milestones', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ taskId: task.id, name: name, startWeek: startWeek, endWeek: endWeek })
  })
    .then(function(res) { return res.json(); })
    .then(function(milestone) {
      task.milestones.push(milestone);
      document.getElementById('milestoneName').value = '';
      document.getElementById('startWeek').value = '1';
      document.getElementById('endWeek').value   = '1';
      displayGanttChart(task);
      displayTasks();
    })
    .catch(function(err) { console.error('Add milestone error:', err); });
});

// Renders the tasks in their respective columns ranked by progress and due date
function displayTasks() {
  upcomingTasks.innerHTML   = '';
  inProgressTasks.innerHTML = '';
  completedTasks.innerHTML  = '';

  tasks.forEach(function(task) {
    var progress = calculateProgress(task);
    var status   = getTaskStatus(task);

    var card = document.createElement('div');
    card.className = 'task-card';

    var dueDateStr = '';
    if (task.due_date) {
      var d = new Date(task.due_date);
      dueDateStr = d.toLocaleDateString('en-GB');
    }

    card.innerHTML =
      '<h3>' + escapeHtml(task.title) + '</h3>' +
      (task.module_code ? '<p class="task-module">' + escapeHtml(task.module_code) + '</p>' : '') +
      '<p>Progress: ' + progress + '%</p>' +
      '<div class="progress-bar"><div class="progress-fill" style="width:' + progress + '%"></div></div>' +
      '<p>' + (dueDateStr ? 'Due: ' + dueDateStr : 'No due date') + '</p>';

    card.addEventListener('click', function() {
      openTaskPopup(task.id);
    });

    if (status === 'completed') {
      completedTasks.appendChild(card);
    } else if (status === 'in_progress') {
      inProgressTasks.appendChild(card);
    } else {
      upcomingTasks.appendChild(card);
    }
  });
}

// Opens the task popup
function openTaskPopup(taskId) {
  selectedTaskId = taskId;
  var task = findSelectedTask();
  if (!task) return;

  taskTitleInput.value = task.title;
  taskDueDate.value    = task.due_date ? task.due_date.substring(0, 10) : '';
  moduleSelect.value   = task.module_code || '';

  displayGanttChart(task);
  taskPopup.classList.remove('hidden');
}

// Displays the gantt chart for a task's milestones 
function displayGanttChart(task) {
  ganttRows.innerHTML = '';

  var moduleCode = task.module_code || null;

  task.milestones.forEach(function(milestone, index) {
    var row = document.createElement('div');
    row.className = 'gantt-row';

    // Name cell — link to module page if a module is set
    var nameCell = document.createElement('span');
    nameCell.className = 'gantt-name-cell';
    if (moduleCode) {
      var link = document.createElement('a');
      link.href        = '/module?module=' + encodeURIComponent(moduleCode);
      link.textContent = milestone.name;
      link.className   = 'gantt-milestone-link';
      nameCell.appendChild(link);
    } else {
      nameCell.textContent = milestone.name;
    }
    row.appendChild(nameCell);

    // 12 week cells
    for (var week = 1; week <= 12; week++) {
      var cell = document.createElement('span');
      cell.className = 'gantt-week-cell';
      if (week >= parseInt(milestone.start_week) && week <= parseInt(milestone.end_week)) {
        cell.className += ' gantt-block';
      }
      row.appendChild(cell);
    }

    // Done checkbox + delete button
    var doneCell = document.createElement('span');
    doneCell.className = 'gantt-done-cell';

    var checkbox = document.createElement('input');
    checkbox.type    = 'checkbox';
    checkbox.checked = milestone.done;

    // Toggles milestone done status on the server then updates display
    (function(m, cb) {
      cb.addEventListener('change', function() {
        m.done = cb.checked;
        fetch('/api/milestones/' + m.id, { method: 'PUT' })
          .catch(function(err) { console.error('Toggle milestone error:', err); });
        displayTasks();
      });
    })(milestone, checkbox);

    var deleteBtn = document.createElement('button');
    deleteBtn.textContent = '×';
    deleteBtn.className   = 'gantt-del-btn';

    // Deletes milestone from the server then from the task's milestones list then updates display
    (function(m, idx) {
      deleteBtn.addEventListener('click', function() {
        fetch('/api/milestones/' + m.id, { method: 'DELETE' })
          .then(function() {
            task.milestones.splice(idx, 1);
            displayGanttChart(task);
            displayTasks();
          })
          .catch(function(err) { console.error('Delete milestone error:', err); });
      });
    })(milestone, index);

    doneCell.appendChild(checkbox);
    doneCell.appendChild(deleteBtn);
    row.appendChild(doneCell);

    ganttRows.appendChild(row);
  });
}

// Calculates the progress percentage of a task based on its milestones
function calculateProgress(task) {
  if (!task.milestones || task.milestones.length === 0) return 0;
  var done = 0;
  task.milestones.forEach(function(m) { if (m.done) done++; });
  return Math.round((done / task.milestones.length) * 100);
}

// returns 'completed' if all milestones are done, 'in_progress' if some are done, and 'upcoming' if none are done
function getTaskStatus(task) {
  var progress = calculateProgress(task);
  if (progress === 100) return 'completed';
  if (progress > 0)    return 'in_progress';
  return 'upcoming';
}

function findSelectedTask() {
  return tasks.find(function(t) { return t.id === selectedTaskId; });
}

//stops cross-site scripting by escaping special characters in user input before rendering it in the HTML
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}
